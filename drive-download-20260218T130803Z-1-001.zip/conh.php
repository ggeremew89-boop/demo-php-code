

<?php
if (isset($_POST['sub'])) {

    $name  = $_POST['name'];
    $age   = $_POST['age'];
    $email = $_POST['email'];

    
    if (empty($name) || empty($age) || empty($email)) {
        echo "All fields are required.";
        
    }

    if (!preg_match("/^[A-Za-z]+$/", $name)) {
        echo "Name must contain only letters.";
        
    }

    if (!preg_match("/^[0-9]+$/", $age)) {
        echo "Age must contain only numbers.";
        
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
        
    }

  
    $con = mysqli_connect("localhost", "root", "root", "group_711");

    if (!$con) {
        die("Not connected to MySQL");
    }

    $db = "INSERT INTO group_data (name, age, email)
           VALUES ('$name', '$age', '$email')";

    if (mysqli_query($con, $db)) {
        echo "Data inserted successfully.";
    } else {
        echo "Failed: " . mysqli_error($con);
    }
}
?>

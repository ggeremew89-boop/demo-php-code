<?php

$con = mysqli_connect("localhost", "root", "root", "group_711");

if (!$con) {
    die("Not connected to MySQL");
}

$db = "CREATE TABLE group_data (
    name VARCHAR(30) NOT NULL,
    age INT NOT NULL,
    email VARCHAR(50) NOT NULL
)";

if (mysqli_query($con, $db)) {
    echo "Table created successfully";
} else {
    echo "Failed to create table: " . mysqli_error($con);
}
?>


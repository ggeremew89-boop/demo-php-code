<!-- .github/copilot-instructions.md -->
# Copilot / AI Agent Instructions — MAU SMS (PHP)

This project is a small procedural PHP monolith used as a Student Management System. Use these notes to be productive quickly when making edits, adding features, or generating code.

Quick summary
- Tech: plain PHP (no framework), MySQL (mysqli), vanilla HTML/CSS.
- Structure: `public/` contains web pages (server-facing entrypoints), `includes/` contains shared code (DB, auth, header/footer), `assets/` contains CSS.
- Run locally: place repository in Apache `htdocs` (this repo is already under `xampp/htdocs/mau_sms`). With XAMPP running, open either `http://localhost/mau_sms/public/` or point your VirtualHost DocumentRoot at the `public/` folder.

Key files / conventions
- Database: `includes/db.php` — creates the database/tables on first run, exposes a global `$conn` (mysqli). Default MySQL credentials: host `localhost`, user `root`, empty password (update if your environment differs).
- Authentication: `includes/auth.php` — session-based helpers: `is_logged_in()`, `require_login()`, `require_role()`, `current_user()`. Many pages include these to protect routes.
- Layout: `includes/header.php` and `includes/footer.php` are manually included by page scripts. Follow their pattern when adding a new page: start a session, include `db.php`/`auth.php` as needed, then `include 'includes/header.php'` before page HTML and `include 'includes/footer.php'` after.
- Pages: each file in `public/` is a self-contained page (e.g., `public/index.php`, `public/dashboard_admin.php`). Forms submit directly to those pages and often use `$_POST` handling at the top of the same file.

Data / domain notes
- Roles used in code: `superadmin`, `admin`, `registrar`, `instructor`, `student`, `department_head`. Expect role-based conditional menus in `includes/header.php`.
- Important DB patterns: `includes/db.php` enforces unique constraints (e.g., unique `course_code`, unique `student_number`) and creates a default superadmin account (`admin` / `admin123`). The app relies on foreign keys with `ON DELETE CASCADE`.
- Example: `course_instructors` is constrained to one instructor per course by making `course_id` unique.

Security & input handling (project-specific patterns)
- The project uses `mysqli_real_escape_string` in places (see `public/index.php` login flow) and `password_hash` / `password_verify` for passwords. When adding SQL, prefer prepared statements (the codebase sometimes uses `mysqli_prepare`).
- Be mindful: many pages assume `$_SESSION` values exist. Use `require_login()` / `require_role()` before accessing `$_SESSION['user_id']` or doing sensitive DB writes.

Developer workflows
- Local runtime: XAMPP (Apache + MySQL). Ensure MySQL is running. The app will create its DB/tables on first access via `includes/db.php`.
- No build system or tests detected. Validate changes by loading pages in a browser (e.g., login, then navigate to role-specific dashboards).

Patterns to follow when editing or adding code
- Keep the procedural style — add helper functions to `includes/` when logic is reused.
- Use `global $conn;` inside functions where DB access is needed to match existing patterns (see `includes/auth.php`).
- When adding a new page, include the header/footer pattern and guard with `require_login()` / `require_role()` if applicable.
- Follow existing naming conventions: `snake_case` filenames for pages (e.g., `view_results.php`, `generate_idcard.php`).

Integration points / external dependencies
- No external composer/npm dependencies detected. The only runtime dependencies are PHP and MySQL (provided by XAMPP commonly).
- External links: footer links to `https://www.mekdela.edu.et` — not required for development.

Examples (copy/paste patterns)
- Login check at top of a page:
```
require_once __DIR__ . '/../includes/auth.php';
require_login();
require_role(['admin','superadmin']);
```
- DB prepared insert example (see `includes/db.php` default admin insertion):
```
$stmt = mysqli_prepare($conn, "INSERT INTO users (username, password, role) VALUES ('admin', ?, 'superadmin')");
mysqli_stmt_bind_param($stmt, 's', $hash);
mysqli_stmt_execute($stmt);
```

What NOT to change lightly
- `includes/db.php` auto-creates schema and default admin — be careful editing schema without migrating existing data.
- Session keys (`user_id`, `username`, `role`) are referenced across pages; renaming them requires sweeping updates.

Where to look when debugging
- DB connection errors: `includes/db.php` outputs die messages on connect/create failure.
- Auth & permissions: `includes/auth.php` and `includes/header.php` menu logic.
- Page flows: check the top of each `public/*.php` file for `$_POST` handlers and redirects.

If you need more
- I merged all discoverable patterns into this file. If you'd like, I can:
- add a short CONTRIBUTING snippet with local run steps or
- update `includes/db.php` to read DB credentials from an `.env`-style config.

— End of agent guidance —

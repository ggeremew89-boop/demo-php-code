<?php
// includes/auth.php

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

/**
 * Check if a user is logged in.
 * @return bool
 */
if (!function_exists('is_logged_in')) {
    function is_logged_in() {
        return isset($_SESSION['user_id']);
    }
}

/**
 * Redirect to login page if user is not logged in.
 */
if (!function_exists('require_login')) {
    function require_login() {
        if (!is_logged_in()) {
            header("Location: ../public/index.php");
            exit;
        }
    }
}

/**
 * Require the current user to have one of the specified roles.
 * @param array $roles List of roles allowed to access the page.
 */
if (!function_exists('require_role')) {
    function require_role($roles = []) {
        require_login(); // Make sure user is logged in first.

        // Normalize requested roles to array
        $allowed = (array)$roles;
        // Get user's roles
        $user_roles = [];
        if (isset($_SESSION['roles']) && is_array($_SESSION['roles'])) {
            $user_roles = $_SESSION['roles'];
        } elseif (isset($_SESSION['role'])) {
            $user_roles = array_map('trim', explode(',', $_SESSION['role']));
        }

        $intersect = array_intersect($allowed, $user_roles);
        if (count($intersect) === 0) {
            // Fallback checks: some accounts may be represented by rows in
            // domain tables (department_heads, instructors) but not have the
            // role string updated in `users.role`. Allow access in that case.
            global $conn;
            $uid = intval($_SESSION['user_id'] ?? 0);
            foreach ($allowed as $want) {
                if ($want === 'department_head') {
                    $r = mysqli_query($conn, "SELECT id FROM department_heads WHERE user_id=$uid LIMIT 1");
                    if ($r && mysqli_num_rows($r) > 0) return true;
                }
                if ($want === 'instructor') {
                    $r = mysqli_query($conn, "SELECT id FROM instructors WHERE user_id=$uid LIMIT 1");
                    if ($r && mysqli_num_rows($r) > 0) return true;
                }
                if ($want === 'student') {
                    $r = mysqli_query($conn, "SELECT id FROM students WHERE user_id=$uid LIMIT 1");
                    if ($r && mysqli_num_rows($r) > 0) return true;
                }
            }

            http_response_code(403);
            die("Access denied: You do not have permission to access this page.");
        }
    }
}

/**
 * Get the full data of the current logged-in user from the database.
 * @return array|null User data associative array or null if not logged in or user not found.
 */
if (!function_exists('current_user')) {
    function current_user() {
        global $conn;
        if (!is_logged_in()) return null;

        $uid = intval($_SESSION['user_id']);
        $result = mysqli_query($conn, "SELECT * FROM users WHERE id = $uid LIMIT 1");

        if ($result && mysqli_num_rows($result) === 1) {
            return mysqli_fetch_assoc($result);
        }
        return null;
    }
}

/**
 * Get the role of the current logged-in user.
 * @return string|null User role or null if not logged in.
 */
if (!function_exists('current_user_role')) {
    function current_user_role() {
        return $_SESSION['role'] ?? null;
    }
}

/**
 * Check if the current user has a specific role.
 * @param string|array $roles Role or list of roles to check
 * @return bool
 */
if (!function_exists('has_role')) {
    function has_role($roles) {
        // desired roles as array
        $wanted = (array)$roles;
        // get user roles array
        if (isset($_SESSION['roles']) && is_array($_SESSION['roles'])) {
            $user_roles = $_SESSION['roles'];
        } elseif (isset($_SESSION['role'])) {
            $user_roles = array_map('trim', explode(',', $_SESSION['role']));
        } else {
            $user_roles = [];
        }

        return count(array_intersect($wanted, $user_roles)) > 0;
    }
}

if (!function_exists('current_user_roles')) {
    function current_user_roles() {
        if (isset($_SESSION['roles']) && is_array($_SESSION['roles'])) return $_SESSION['roles'];
        if (isset($_SESSION['role'])) return array_map('trim', explode(',', $_SESSION['role']));
        return [];
    }
}

if (!function_exists('current_active_role')) {
    function current_active_role() {
        // preferred explicit active role, else first available role
        $roles = current_user_roles();
        if (isset($_SESSION['active_role']) && in_array($_SESSION['active_role'], $roles)) {
            return $_SESSION['active_role'];
        }
        return $roles[0] ?? null;
    }
}

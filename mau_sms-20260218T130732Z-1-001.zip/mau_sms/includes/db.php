<?php
// includes/db.php

/* ===========================
   DATABASE CONFIG
=========================== */
$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "MAU_sms";

/* ===========================
   CONNECT MYSQL
=========================== */
$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS);
if (!$conn) {
    die("MySQL connection failed: " . mysqli_connect_error());
}

/* ===========================
   CREATE & SELECT DATABASE
=========================== */
if (!mysqli_select_db($conn, $DB_NAME)) {
    if (!mysqli_query(
        $conn,
        "CREATE DATABASE IF NOT EXISTS `$DB_NAME`
         CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
    )) {
        die("Database creation failed: " . mysqli_error($conn));
    }
    mysqli_select_db($conn, $DB_NAME);
}

/* ===========================
   HELPER FUNCTIONS
=========================== */
if (!function_exists('indexExists')) {
    function indexExists($conn, $table, $index) {
        $res = mysqli_query($conn, "SHOW INDEX FROM `$table` WHERE Key_name='$index'");
        return mysqli_num_rows($res) > 0;
    }
}

/* ===========================
   USERS
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(30) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB
");

/* DEFAULT SUPERADMIN */
$res = mysqli_query($conn, "SELECT id FROM users WHERE username='admin' LIMIT 1");
if (mysqli_num_rows($res) === 0) {
    $hash = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = mysqli_prepare(
        $conn,
        "INSERT INTO users (username, password, role) VALUES ('admin', ?, 'superadmin')"
    );
    mysqli_stmt_bind_param($stmt, 's', $hash);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

/* ===========================
   STUDENTS
=========================== */
mysqli_query($conn, "CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    student_number VARCHAR(50) UNIQUE NOT NULL,
    fname VARCHAR(80) NOT NULL,
    lname VARCHAR(80) NOT NULL,
    gender VARCHAR(10),
    department VARCHAR(120),
    year_level VARCHAR(20),
    email VARCHAR(255),
    phone VARCHAR(255),
    registration_status VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB");

/* ===========================
   INSTRUCTORS
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS instructors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    instructor_code VARCHAR(50) UNIQUE,
    fname VARCHAR(80) NOT NULL,
    lname VARCHAR(80) NOT NULL,
    department VARCHAR(120),
    email VARCHAR(255),
    phone VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB
");

/* ===========================
   DEPARTMENT HEADS
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS department_heads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    department VARCHAR(120) NOT NULL,
    fname VARCHAR(80),
    lname VARCHAR(80),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB
");

/* ===========================
   ADMINS
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB
");

/* ===========================
   REGISTRARS
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS registrars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB
");

/* ===========================
   DEPARTMENTS
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    department_code VARCHAR(50) UNIQUE NOT NULL,
    department_name VARCHAR(200) NOT NULL,
    faculty VARCHAR(200) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB
");

/* ===========================
   COURSES
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(50) UNIQUE NOT NULL,
    course_name VARCHAR(150) NOT NULL,
    department VARCHAR(120) NOT NULL,
semester VARCHAR(120) DEFAULT '1rt',
    credit_hour INT DEFAULT 3,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB
");

// Ensure legacy installations get the `semester` column if it was missing
$colCheck = mysqli_query($conn, "SHOW COLUMNS FROM courses LIKE 'semester'");
if (!$colCheck || mysqli_num_rows($colCheck) === 0) {
    mysqli_query($conn, "ALTER TABLE courses ADD COLUMN semester VARCHAR(120) DEFAULT '1rt'");
}

/* ===========================
   COURSE_INSTRUCTORS
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS course_instructors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    instructor_id INT NOT NULL,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    FOREIGN KEY (instructor_id) REFERENCES instructors(id) ON DELETE CASCADE
) ENGINE=InnoDB
");

/* ===== ENFORCE ONE COURSE → ONE INSTRUCTOR ===== */
if (indexExists($conn, 'course_instructors', 'course_id')) {
    mysqli_query($conn, "ALTER TABLE course_instructors DROP INDEX course_id");
}
mysqli_query($conn, "ALTER TABLE course_instructors ADD UNIQUE (course_id)");

/* ===========================
   REGISTRATIONS
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    semester VARCHAR(50) NOT NULL,
    year VARCHAR(10) NOT NULL,
    status VARCHAR(30) DEFAULT 'registered',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_registration (student_id, course_id, semester, year),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB
");

/* ===========================
   TIMETABLE
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS timetable (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_id INT NOT NULL,
    instructor_id INT NOT NULL,
    day_of_week VARCHAR(20),
    start_time TIME,
    end_time TIME,
    location VARCHAR(120),
    semester VARCHAR(50),
    year VARCHAR(10),
    FOREIGN KEY (course_id) REFERENCES courses(id),
    FOREIGN KEY (instructor_id) REFERENCES instructors(id)
) ENGINE=InnoDB
");

/* ===========================
   STUDENT RESULTS
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS student_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    semester VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    continuous_mark DOUBLE,
    final_mark DOUBLE,
    status VARCHAR(50) DEFAULT 'Completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_result (student_id, course_id, semester, year),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB
");

/* ===========================
   STUDENT REGISTRATION
=========================== */
mysqli_query($conn, "
CREATE TABLE IF NOT EXISTS student_registration (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    semester VARCHAR(20) NOT NULL,
    status VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB
");

?>

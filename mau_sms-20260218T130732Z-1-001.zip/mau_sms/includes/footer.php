<?php
// includes/footer.php
?>

</div> <!-- End container -->
<style >
    .footer {
        text_align: center;
        panding:1px;
        margin-top: 2px;
        font-size: 20px;
        color: #8179ccff;
        border-top: 1px solid #8179ccff;
        background-color: #151615ff;
        color: rgba(238, 228, 228, 1);
    }
    .div{

        text-align: center;
        padding:10px;
        margin-bottom:10px;
        color: rgba(224, 216, 216, 1);
    }
    </style>
    <footer class="footer">
        <div class="div">
        <p>&copy; <?php echo date("Y"); ?> Mekdela Amba University - Student Management System</p>
        <a href="contact.php">contactus</a><br>
          <a href="home.php">Home</a><br>
        <a href="about.php">aboutus</a><br>
        <a href="https://www.mekdela.edu.et" target="_blank">Visit mau Website</a><br>
      </div>
      
    </footer>
</body>
</html>


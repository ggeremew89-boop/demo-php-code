<?php
if(session_status() == PHP_SESSION_NONE) session_start();
// Ensure auth helpers are available when header is included directly (e.g., login page)
if (!function_exists('current_user_roles')) {
    require_once __DIR__ . '/auth.php';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>MAU Student Management System</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif; 
            background: #f9f9f9; 
            margin: 0; 
            padding: 0; 
            color: #333;
        }
        .nav {
            background-color: #003366; 
            color: white; 
            padding: 1rem 2rem;
            display: flex; 
            justify-content: space-between; 
            align-items: center;
        }
        .nav-left {
            display: flex;
            align-items: center;
        }
        .nav-left img {
            height: 40px;
            margin-right: 10px;
        }
        .nav-left strong {
            vertical-align: middle;
            font-size: 1.25rem;
        }
        .nav a {
            color: white; 
            margin-left: 1rem; 
            text-decoration: none; 
            font-weight: bold;
        }
        .nav a:hover {
            text-decoration: underline;
        }
        .menu {
            background: #0055a5; 
            padding: 0.5rem 2rem; 
            display: flex;
            gap: 1rem;
        }
        .menu a {
            color: white; 
            text-decoration: none; 
            font-weight: bold;
        }
        .menu a:hover {
            text-decoration: underline;
        }
        .container {
            max-width: 900px; 
            margin: 2rem auto; 
            padding: 1rem; 
            background: white; 
            border-radius: 8px; 
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
        }
        h1, h2 {
            color: #003366;
        }
        .footer {
            text-align: center; 
            padding: 1rem; 
            margin-top: 2rem; 
            font-size: 0.9rem; 
            color: #777; 
            border-top: 1px solid #ccc;
        }
    </style>
</head>
<body>
<div class="nav">
    <div class="nav-left">
        <img src="../assets/image/ss.jfif" alt="mm">
        <strong>MAU Student Management System</strong>
    </div>
    <div class="nav-right">
        <?php if(isset($_SESSION['username'])): ?>
            <?php
                if (function_exists('current_user_roles')) {
                    $roles = current_user_roles();
                } elseif (isset($_SESSION['role'])) {
                    $roles = array_map('trim', explode(',', $_SESSION['role']));
                } else {
                    $roles = [];
                }
                if (function_exists('current_active_role')) {
                    $active = current_active_role();
                } else {
                    $active = $roles[0] ?? '';
                }
            ?>
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?> (active: <?php echo htmlspecialchars($active); ?>)</span>
            <?php if (count($roles) > 1): ?>
                <form method="POST" action="/mau_sms/public/switch_role.php" style="display:inline;margin-left:8px">
                    <select name="active_role" onchange="this.form.submit()">
                        <?php foreach($roles as $r): ?>
                            <option value="<?= htmlspecialchars($r) ?>" <?= $r === $active ? 'selected' : '' ?>><?= htmlspecialchars($r) ?></option>
                        <?php endforeach; ?>
                    </select>
                </form>
            <?php endif; ?>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="index.php">Login</a>
        <?php endif; ?>
    </div>
</div>

<?php if(isset($_SESSION['role'])): ?>
<div class="menu">
    <?php
    // Show menu for the currently active role to avoid confusion
    $active_role = function_exists('current_active_role') ? current_active_role() : ($_SESSION['role'] ?? null);

    if (in_array($active_role, ['superadmin','admin'])): ?>
        <a href="home.php">Home</a>
        <a href="add_user.php">Register Students and Instructors</a>
        <a href="view_registrations.php">View Student Registrations</a>
        <a href="departments.php">Add Department</a>
        <a href="department_head.php">head Department</a>
        <a href="manage_admins.php">Manage Admins</a>

    <?php elseif ($active_role === 'registrar'): ?>
        <a href="dashboard_registrar.php">Registrar Dashboard</a>
        <a href="registrar_add_user.php">Register Students</a>
        <a href="registrar_view.php">View Student Registrations</a>
        <a href="departments.php">View Departments</a>
       
        <a href="report_registrar.php">Registrar Reports</a>
        
       

    <?php elseif ($active_role === 'instructor'): ?>
        <a href="dashboard_instructor.php">Instructor Dashboard</a>
        <a href="instructor_upload_results.php">Upload Results</a>
        <a href="timetable_student.php">Timetable</a>

    <?php elseif ($active_role === 'student'): ?>
        <a href="dashboard_student.php">My Dashboard</a>
        <a href="my_registrations.php">My Registrations</a>
        <a href="timetable_student.php">Timetable</a>
      
        <a href="view_results.php">My Results</a>

    <?php elseif ($active_role === 'department_head'): ?>
        <a href="dashboard_department_head.php">Dashboard</a>
        <a href="assign_teacher.php">Assign Teacher to Course</a>
        <a href="view_registrations.php">View Student Registrations</a>
        <a href="view_results.php">View/Submit Results</a>
        <a href="timetable_hod.php">Table Schedule</a>
        <a href="courses.php">Add Course</a>
        <a href="courses_list.php">Manage Courses</a>
        <a href="report_department.php">Department Report</a>
        <a href="register_department_courses.php">Register Department Courses</a>
    <?php endif; ?>
</div>
<?php endif; ?>

<div class="container">
<!-- Page content starts here -->

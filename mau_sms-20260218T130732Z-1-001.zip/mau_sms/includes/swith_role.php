<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = $_POST['active_role'] ?? '';
    $roles = current_user_roles();
    if (in_array($role, $roles)) {
        $_SESSION['active_role'] = $role;
    }
}

$redirect = $_SERVER['HTTP_REFERER'] ?? 'home.php';
header('Location: ' . $redirect);
exit;

?>

<?php
// Include common header
include __DIR__ . '/../includes/header.php';
?>

<div class="container" style="max-width: 900px;
    margin: 50px auto;
    background: #d8e0e6ff;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
">

    <h1>About Us</h1>

    <p>
        Mekdela Amba University (MAU) is a public higher education institution in Ethiopia,
        committed to excellence in teaching, research, and community service.
    </p>

    <p>
        The Student Management System (SMS) of Mekdela Amba University is designed to
        efficiently manage academic records, student information, course registrations,
        and administrative processes.
    </p>

    <h3>Our Mission</h3>
    <p>
        To produce competent, innovative, and socially responsible graduates through
        quality education, research, and community engagement.
    </p>

    <h3>Our Vision</h3>
    <p>
        To become one of Ethiopia’s leading universities recognized for academic excellence
        and impactful research.
    </p>

    <h3>Core Values</h3>
    <ul>
        <li>Academic Excellence</li>
        <li>Integrity and Accountability</li>
        <li>Innovation</li>
        <li>Community Service</li>
        <li>Diversity and Inclusion</li>
    </ul>

</div>

<?php
// Include common footer
include __DIR__ . '/../includes/footer.php';
?>

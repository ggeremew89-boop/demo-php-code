<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin','admin','registrar']);
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

/* =====================
   INITIALIZE VARIABLES
===================== */
$error = '';
$success = '';
$added_role = '';
 
function clean($v) {
    return trim($v === null ? '' : htmlspecialchars($v, ENT_QUOTES, 'UTF-8'));
}
function valid_username($u) {
    return preg_match('/^[a-zA-Z0-9_]{4,30}$/', $u);
}
function valid_password($p) {
    return is_string($p) && strlen($p) >= 7 && preg_match('/[a-z]/', $p) && preg_match('/[A-Z]/', $p) && preg_match('/[0-9]/', $p);
}
function valid_email($e) {
    if(!$e) return true; // optional in many forms; caller enforces requiredness
    return filter_var($e, FILTER_VALIDATE_EMAIL) !== false;
}
function valid_phone($p) {
    if(!$p) return true;
    // allow digits, spaces, plus, hyphen, parentheses
    return preg_match('/^[0-9+()\-\s]{10}$/', $p);
}
function valid_name($n) {
    $n = trim($n);
    return strlen($n) >= 1 && strlen($n) <= 50 && preg_match('/^[a-zA-Z\s]+$/', $n);
}
function valid_year_level($y) {
    $y = trim($y);
    return is_numeric($y) && intval($y) >= 1 && intval($y) <= 4;
}
function valid_department($d, $departments) {
    foreach ($departments as $dep) {
        if ($dep['department_name'] === $d) return true;
    }
    return false;
}

/* =====================
   FETCH DEPARTMENTS
===================== */
$departments = [];
$dep_res = mysqli_query($conn, "SELECT department_code, department_name FROM departments ORDER BY department_name");
while ($dep = mysqli_fetch_assoc($dep_res)) {
    $departments[] = $dep;
}
mysqli_free_result($dep_res);

/* =====================
   HANDLE FORM SUBMIT
===================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {

    $current_role = $_SESSION['role'];

    // Collect all inputs
    $role = $_POST['role'] ?? '';
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    // Role-specific inputs
    $student_number = $_POST['student_student_number'] ?? '';
    $student_fname = $_POST['student_fname'] ?? '';
    $student_lname = $_POST['student_lname'] ?? '';
    $student_gender = $_POST['student_gender'] ?? '';
    $student_department = $_POST['student_department'] ?? '';
    $student_year_level = $_POST['student_year_level'] ?? '';
    $student_email = $_POST['student_email'] ?? '';
    $student_phone = $_POST['student_phone'] ?? '';

    $instr_code = $_POST['instr_instructor_code'] ?? '';
    $instr_fname = $_POST['instr_fname'] ?? '';
    $instr_lname = $_POST['instr_lname'] ?? '';
    $instr_department = $_POST['instr_department'] ?? '';
    $instr_email = $_POST['instr_email'] ?? '';
    $instr_phone = $_POST['instr_phone'] ?? '';

    /* GENERAL VALIDATION */
    if (!in_array($role, ['student', 'instructor'])) {
        $error = "Invalid role selected.";
    } elseif ($current_role === 'registrar' && $role === 'instructor') {
        $error = "You are not allowed to add instructor accounts.";
    } elseif (!$username || !$password || !$confirm) {
        $error = "All account fields are required.";
    } elseif (!valid_username($username)) {
        $error = "Username must be 4–30 characters (letters, numbers, underscore).";
    } elseif (!valid_password($password)) {
        $error = "Password must be at least 7 characters with at least one lowercase, one uppercase, and one number.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    }

    /* ROLE-SPECIFIC VALIDATION */
    if (!$error) {
        if ($role === 'student') {
            if (!$student_number || !$student_fname || !$student_lname || !$student_department || !$student_year_level) {
                $error = "All required student fields must be filled.";
            } elseif (!valid_name($student_fname) || !valid_name($student_lname)) {
                $error = "Names must be 1-50 characters, letters and spaces only.";
            } elseif (!in_array($student_gender, ['Male', 'Female'])) {
                $error = "Invalid gender value.";
            } elseif (!valid_department($student_department, $departments)) {
                $error = "Invalid department selected.";
            } elseif (!valid_year_level($student_year_level)) {
                $error = "Year level must be 1-4.";
            } elseif (!valid_email($student_email)) {
                $error = "Invalid student email.";
            } elseif (!valid_phone($student_phone)) {
                $error = "Invalid student phone.";
            }
        } elseif ($role === 'instructor') {
            if (!$instr_code || !$instr_fname || !$instr_lname || !$instr_department) {
                $error = "All required instructor fields must be filled.";
            } elseif (!valid_name($instr_fname) || !valid_name($instr_lname)) {
                $error = "Names must be 1-50 characters, letters and spaces only.";
            } elseif (!valid_department($instr_department, $departments)) {
                $error = "Invalid department selected.";
            } elseif (!valid_email($instr_email)) {
                $error = "Invalid instructor email.";
            } elseif (!valid_phone($instr_phone)) {
                $error = "Invalid instructor phone.";
            }
        }
    }

    /* UNIQUENESS CHECKS */
    if (!$error) {
        // Check username
        $chk = mysqli_prepare($conn, "SELECT id FROM users WHERE username=?");
        mysqli_stmt_bind_param($chk, 's', $username);
        mysqli_stmt_execute($chk);
        mysqli_stmt_store_result($chk);
        if (mysqli_stmt_num_rows($chk) > 0) {
            $error = "Username already exists.";
        }
        mysqli_stmt_close($chk);

        if ($role === 'student') {
            $chk2 = mysqli_prepare($conn, "SELECT id FROM students WHERE student_number=? LIMIT 1");
            mysqli_stmt_bind_param($chk2, 's', $student_number);
            mysqli_stmt_execute($chk2);
            mysqli_stmt_store_result($chk2);
            if (mysqli_stmt_num_rows($chk2) > 0) {
                $error = "Student number already exists.";
            }
            mysqli_stmt_close($chk2);
        } elseif ($role === 'instructor') {
            $chk3 = mysqli_prepare($conn, "SELECT id FROM instructors WHERE instructor_code=? LIMIT 1");
            mysqli_stmt_bind_param($chk3, 's', $instr_code);
            mysqli_stmt_execute($chk3);
            mysqli_stmt_store_result($chk3);
            if (mysqli_stmt_num_rows($chk3) > 0) {
                $error = "Instructor code already exists.";
            }
            mysqli_stmt_close($chk3);
        }
    }

    /* INSERT USER */
    if (!$error) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $ins = mysqli_prepare($conn, "INSERT INTO users (username,password,role) VALUES (?,?,?)");
        mysqli_stmt_bind_param($ins, 'sss', $username, $hash, $role);
        if (!mysqli_stmt_execute($ins)) {
            $error = "Failed to create user.";
        } else {
            $user_id = mysqli_insert_id($conn);
        }
        mysqli_stmt_close($ins);
    }

    /* INSERT STUDENT OR INSTRUCTOR */
    if (!$error && $role === 'student') {
        $ins2 = mysqli_prepare($conn,
            "INSERT INTO students 
            (user_id, student_number, fname, lname, gender, department, year_level, email, phone, registration_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Not Registered')"
        );
        mysqli_stmt_bind_param(
            $ins2,
            'issssssss',
            $user_id,
            $student_number,
            $student_fname,
            $student_lname,
            $student_gender,
            $student_department,
            $student_year_level,
            $student_email,
            $student_phone
        );
        if (mysqli_stmt_execute($ins2)) {
            $success = "Student added successfully.";
            $added_role = 'student';
        } else {
            $error = "Failed to add student: " . mysqli_stmt_error($ins2);
        }
        mysqli_stmt_close($ins2);
    } elseif (!$error && $role === 'instructor') {
        $ins3 = mysqli_prepare($conn,
            "INSERT INTO instructors 
            (user_id, instructor_code, fname, lname, department, email, phone)
            VALUES (?,?,?,?,?,?,?)"
        );
        mysqli_stmt_bind_param(
            $ins3,
            'issssss',
            $user_id,
            $instr_code,
            $instr_fname,
            $instr_lname,
            $instr_department,
            $instr_email,
            $instr_phone
        );
        if (mysqli_stmt_execute($ins3)) {
            $success = "Instructor added successfully.";
            $added_role = 'instructor';
        } else {
            $error = "Failed to add instructor: " . mysqli_stmt_error($ins3);
        }
        mysqli_stmt_close($ins3);
    }
}
?>

<h2>Add User (Student / Instructor)</h2>

<?php if($error): ?>
<div style="color:red"><?= $error ?></div>
<?php endif; ?>

<?php if($success): ?>
<div style="color:green"><?= $success ?></div>
<?php endif; ?>

<form method="POST">
<input type="hidden" name="add_user" value="1">

<label>Role</label><br>
<select name="role" id="role" onchange="toggle()" required>
<option value="">-- Select --</option>
<option value="student">Student</option>
<?php if($_SESSION['role'] !== 'registrar'): ?>
<option value="instructor">Instructor</option>
<?php endif; ?>
</select><br><br>

<label>Username</label><br>
<input name="username" pattern="[a-zA-Z0-9_]{4,30}" required><br><br>

<label>Password</label><br>
<input type="password" name="password" minlength="7" required><br><br>

<label>Confirm Password</label><br>
<input type="password" name="confirm_password" minlength="7" required><br><br>

<div id="student_fields" style="display:none">
<h4>Student Info</h4>
<input name="student_student_number" placeholder="Student Number"><br><br>
<input name="student_fname" placeholder="First Name"><br><br>
<input name="student_lname" placeholder="Last Name"><br><br>
<select name="student_gender">
<option value="Male">Male</option>
<option value="Female">Female</option>
</select><br><br>
<select name="student_department">
<option value="">-- Department --</option>
<?php foreach($departments as $d): ?>
<option value="<?= $d['department_name'] ?>"><?= $d['department_name'] ?></option>
<?php endforeach; ?>
</select><br><br>
<input name="student_year_level" placeholder="Year Level" required><br><br>
<input type="email" name="student_email" placeholder="Email"><br><br>
<input name="student_phone" placeholder="Phone"><br><br>
</div>

<div id="instr_fields" style="display:none">
<h4>Instructor Info</h4>
<input name="instr_instructor_code" placeholder="Instructor Code"><br><br>
<input name="instr_fname" placeholder="First Name"><br><br>
<input name="instr_lname" placeholder="Last Name"><br><br>
<select name="instr_department">
<option value="">-- Department --</option>
<?php foreach($departments as $d): ?>
<option value="<?= $d['department_name'] ?>"><?= $d['department_name'] ?></option>
<?php endforeach; ?>
</select><br><br>
<input type="email" name="instr_email" placeholder="Email"><br><br>
<input name="instr_phone" placeholder="Phone"><br><br>
</div>

<button type="submit">Add User</button>
</form>

<script>
function toggle(){
    let r = document.getElementById('role').value;
    document.getElementById('student_fields').style.display = (r==='student')?'block':'none';
    document.getElementById('instr_fields').style.display = (r==='instructor')?'block':'none';
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>

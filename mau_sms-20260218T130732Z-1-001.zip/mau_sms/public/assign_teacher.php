<?php
session_start();

/* ===========================
   AUTH & DATABASE
=========================== */
require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']);
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

/* ===========================
   VARIABLES
=========================== */
$error   = '';
$success = '';

/* ===========================
   1. CHECK LOGIN
=========================== */
$user_id = $_SESSION['user_id'] ?? 0;
if ($user_id <= 0) {
    die("<div style='color:red'>User not logged in.</div>");
}

/* ===========================
   2. GET DEPARTMENT
=========================== */
$stmt = mysqli_prepare(
    $conn,
    "SELECT department FROM department_heads WHERE user_id = ?"
);
if (!$stmt) {
    die("Prepare failed: " . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($res);
mysqli_stmt_close($stmt);

if (!$row) {
    die("<div style='color:red'>Department not found.</div>");
}
$department = $row['department'];

// Optional prefill: allow link to preselect a course when coming from timetable
$prefill_course_id = intval($_GET['prefill_course_id'] ?? 0);

/* ===========================
   ENSURE DEPT-HEAD IS AN INSTRUCTOR ROW
   If the department head user does not have an `instructors` row,
   create one so they can appear in instructor selection and be assigned.
=========================== */
$chk_instr = mysqli_prepare($conn, "SELECT id FROM instructors WHERE user_id = ? LIMIT 1");
mysqli_stmt_bind_param($chk_instr, 'i', $user_id);
mysqli_stmt_execute($chk_instr);
mysqli_stmt_store_result($chk_instr);
if (mysqli_stmt_num_rows($chk_instr) === 0) {
    // get name from department_heads to populate instructor record
    $dhq = mysqli_prepare($conn, "SELECT fname, lname FROM department_heads WHERE user_id = ? LIMIT 1");
    mysqli_stmt_bind_param($dhq, 'i', $user_id);
    mysqli_stmt_execute($dhq);
    $dhres = mysqli_stmt_get_result($dhq);
    $dhrow = mysqli_fetch_assoc($dhres);
    mysqli_stmt_close($dhq);

    $instr_code = 'DH' . $user_id;
    $fname = $dhrow['fname'] ?? 'Dept';
    $lname = $dhrow['lname'] ?? 'Head';

    $ins_instr = mysqli_prepare($conn,
        "INSERT INTO instructors (user_id, instructor_code, fname, lname, department) VALUES (?,?,?,?,?)"
    );
    mysqli_stmt_bind_param($ins_instr, 'issss', $user_id, $instr_code, $fname, $lname, $department);
    mysqli_stmt_execute($ins_instr);
    mysqli_stmt_close($ins_instr);
}
mysqli_stmt_close($chk_instr);

/* ===========================
   3. HANDLE FORM SUBMISSION
=========================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign'])) {

    $course_id     = intval($_POST['course_id'] ?? 0);
    $instructor_id = intval($_POST['instructor_id'] ?? 0);

    if ($course_id > 0 && $instructor_id > 0) {

        /* ---- CHECK: COURSE ALREADY ASSIGNED? ---- */
        $check_stmt = mysqli_prepare(
            $conn,
            "SELECT id FROM course_instructors WHERE course_id = ?"
        );

        if (!$check_stmt) {
            $error = "Prepare failed: " . mysqli_error($conn);
        } else {

            mysqli_stmt_bind_param($check_stmt, 'i', $course_id);
            mysqli_stmt_execute($check_stmt);
            mysqli_stmt_store_result($check_stmt);

            if (mysqli_stmt_num_rows($check_stmt) > 0) {
                $error = "This course is already assigned to another instructor.";
            } else {

                /* ---- INSERT ASSIGNMENT ---- */
                $insert_stmt = mysqli_prepare(
                    $conn,
                    "INSERT INTO course_instructors (course_id, instructor_id)
                     VALUES (?, ?)"
                );

                if (!$insert_stmt) {
                    $error = "Prepare failed: " . mysqli_error($conn);
                } else {

                    mysqli_stmt_bind_param($insert_stmt, 'ii', $course_id, $instructor_id);

                    if (mysqli_stmt_execute($insert_stmt)) {
                        $success = "Instructor assigned successfully.";
                    } else {
                        $error = "Insert failed: " . mysqli_stmt_error($insert_stmt);
                    }

                    mysqli_stmt_close($insert_stmt);
                }
            }

            mysqli_stmt_close($check_stmt);
        }

    } else {
        $error = "Please select both course and instructor.";
    }
}

/* ===========================
   4. FETCH COURSES
=========================== */
$courses_stmt = mysqli_prepare(
    $conn,
    "SELECT id, course_code, course_name
     FROM courses
     WHERE department = ?
     ORDER BY course_code"
);
mysqli_stmt_bind_param($courses_stmt, 's', $department);
mysqli_stmt_execute($courses_stmt);
$courses = mysqli_stmt_get_result($courses_stmt);
mysqli_stmt_close($courses_stmt);

/* ===========================
   5. FETCH INSTRUCTORS
=========================== */
$instructors_stmt = mysqli_prepare(
    $conn,
    "SELECT id, fname, lname
     FROM instructors
     WHERE department = ?
     ORDER BY fname, lname"
);
mysqli_stmt_bind_param($instructors_stmt, 's', $department);
mysqli_stmt_execute($instructors_stmt);
$instructors = mysqli_stmt_get_result($instructors_stmt);
mysqli_stmt_close($instructors_stmt);

/* ===========================
   6. FETCH ASSIGNMENTS
=========================== */
$assign_stmt = mysqli_prepare(
    $conn,
    "SELECT ci.id, c.course_code, c.course_name, i.fname, i.lname
     FROM course_instructors ci
     JOIN courses c ON ci.course_id = c.id
     JOIN instructors i ON ci.instructor_id = i.id
     WHERE c.department = ?
     ORDER BY c.course_code"
);
mysqli_stmt_bind_param($assign_stmt, 's', $department);
mysqli_stmt_execute($assign_stmt);
$assignments = mysqli_stmt_get_result($assign_stmt);
mysqli_stmt_close($assign_stmt);
?>

<!-- ===========================
     HTML OUTPUT
=========================== -->

<h2>Assign Instructor (Department: <?= htmlspecialchars($department) ?>)</h2>

<?php if ($error): ?>
    <div style="color:red"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div style="color:green"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="POST">
    <label>Course</label><br>
    <select name="course_id" required>
        <option value="">-- Select Course --</option>
        <?php while ($c = mysqli_fetch_assoc($courses)): ?>
            <option value="<?= $c['id'] ?>" <?= ($prefill_course_id > 0 && $prefill_course_id == $c['id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['course_code'] . ' - ' . $c['course_name']) ?>
            </option>
        <?php endwhile; ?>
    </select><br><br>

    <label>Instructor</label><br>
    <select name="instructor_id" required>
        <option value="">-- Select Instructor --</option>
        <?php while ($i = mysqli_fetch_assoc($instructors)): ?>
            <option value="<?= $i['id'] ?>">
                <?= htmlspecialchars($i['fname'] . ' ' . $i['lname']) ?>
            </option>
        <?php endwhile; ?>
    </select><br><br>

    <button type="submit" name="assign">Assign</button>
</form>

<h3>Current Assignments</h3>

<table border="1" cellpadding="6" cellspacing="0" width="100%">
    <tr style="background:#003366;color:#fff">
        <th>Course</th>
        <th>Instructor</th>
        <th>Action</th>
    </tr>

    <?php if (mysqli_num_rows($assignments) === 0): ?>
        <tr>
            <td colspan="3" align="center">No assignments found</td>
        </tr>
    <?php else: ?>
        <?php while ($a = mysqli_fetch_assoc($assignments)): ?>
        <tr>
            <td><?= htmlspecialchars($a['course_code'] . ' - ' . $a['course_name']) ?></td>
            <td><?= htmlspecialchars($a['fname'] . ' ' . $a['lname']) ?></td>
            <td>
                <form method="POST" action="delete_assignment.php"
                      onsubmit="return confirm('Delete this assignment?');">
                    <input type="hidden" name="assignment_id" value="<?= $a['id'] ?>">
                    <button style="background:red;color:white;border:none;padding:5px">
                        Delete
                    </button>
                </form>
                    <br>
                    <a href="view_course_students.php?course_id=<?= (int)$a['id'] ?>">View Students</a>
            </td>
        </tr>
        <?php endwhile; ?>
    <?php endif; ?>
</table>

<?php include __DIR__ . '/../includes/footer.php'; ?>

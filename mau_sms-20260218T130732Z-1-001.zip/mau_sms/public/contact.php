<?php
include __DIR__ . '/../includes/header.php';
?>

<div class="container" style="max-width:800px; margin:50px auto; background:#fff; padding:30px; border-radius:8px; box-shadow:0 0 10px rgba(0,0,0,0.1);">

    <h1>Contact Us</h1>

    <p>If you have any questions or need assistance, feel free to reach out to us:</p>

    <ul style="line-height:1.8;">
        <li><strong>Email:</strong> info@mau.edu.et</li>
        <li><strong>Phone:</strong> +251 11 123 4567</li>
        <li><strong>Address:</strong> Mekdela Amba University, Mekdela, Ethiopia</li>
    </ul>

</div>

<?php
include __DIR__ . '/../includes/footer.php';
?>

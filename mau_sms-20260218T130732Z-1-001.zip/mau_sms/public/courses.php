<?php
// courses_list.php

session_start();

require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']); 

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

// 1. Get logged-in user ID
$user_id = $_SESSION['user_id'] ?? 0;
if ($user_id <= 0) {
    die("<div style='color:red'>User not logged in.</div>");
}

// 2. Get department of logged-in department head
$stmt = mysqli_prepare($conn, "SELECT department FROM department_heads WHERE user_id = ?");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$dept_row = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$dept_row) {
    die("<div style='color:red'>Department not found for your user.</div>");
}
$department = $dept_row['department'];

// 3. Fetch courses ONLY in this department
$query = "SELECT * FROM courses WHERE department = ? ORDER BY id DESC";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "s", $department);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

if (!$res) {
    die("Database error: " . mysqli_error($conn));
}
?>

<h2>Courses in Department: <?= htmlspecialchars($department) ?></h2>

<a class="btn" href="courses_add.php">+ Add Course</a>

<table class="table" border="1" cellpadding="5" cellspacing="0" style="width:100%;">
    <thead>
        <tr>
            <th>ID</th>
            <th>Code</th>
            <th>Name</th>
            <th>Department</th>
            <th>Credits</th>
            <th>semester</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php if (mysqli_num_rows($res) === 0): ?>
        <tr><td colspan="7" style="text-align:center;">No courses found in your department.</td></tr>
    <?php else: ?>
        <?php while ($r = mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?= $r['id']; ?></td>
            <td><?= htmlspecialchars($r['course_code']); ?></td>
            <td><?= htmlspecialchars($r['course_name']); ?></td>
            <td><?= htmlspecialchars($r['department']); ?></td>
            <td><?= htmlspecialchars($r['credit_hour']); ?></td>
            <td><?= htmlspecialchars($r['semester'] ?? ''); ?></td>
            <td>
                <a href="courses_edit.php?id=<?= $r['id']; ?>">Edit</a> |
                <a href="courses_delete.php?id=<?= $r['id']; ?>" onclick="return confirm('Delete this course?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    <?php endif; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

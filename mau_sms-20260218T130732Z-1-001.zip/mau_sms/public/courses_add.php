<?php
// courses_add.php

session_start();

require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$success = '';

/* ===============================
   GET LOGGED-IN USER DEPARTMENT (no prepared statements)
================================ */
$user_id = $_SESSION['user_id'] ?? 0;
$user_id = (int)$user_id; // cast to int for safety

if ($user_id <= 0) {
    die("<div style='color:red'>User not logged in.</div>");
}

$sql = "SELECT department FROM department_heads WHERE user_id = $user_id LIMIT 1";
$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) === 0) {
    die("<div style='color:red'>Department not found for your user.</div>");
}

$dept_row = mysqli_fetch_assoc($result);
$department = $dept_row['department'];

/* ===============================
   HANDLE FORM SUBMISSION
================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    // Trim and sanitize inputs
    $course_code = strtoupper(trim($_POST['course_code'] ?? ''));
    $course_name = trim($_POST['course_name'] ?? '');
    $credit_hour = intval($_POST['credit_hour'] ?? 3);
    $semester = trim($_POST['semester'] ?? '');

    // Validate inputs
    if (!preg_match('/^[A-Z]+[0-9]{2,10}$/', $course_code)) {
        $error = "Course code must be 2–10 characters (letters, numbers, - or _).";
    } elseif (strlen($course_name) < 3 || strlen($course_name) > 100) {
        $error = "Course name must be between 3 and 100 characters.";
    } elseif ($credit_hour < 1 || $credit_hour > 10) {
        $error = "Credit hour must be a number between 1 and 10.";
    } else {
        // Check duplicate course_code in the department
        $dup_sql = "SELECT id FROM courses WHERE course_code = '$course_code' AND department = '$department' LIMIT 1";
        $dup_result = mysqli_query($conn, $dup_sql);

        if ($dup_result && mysqli_num_rows($dup_result) > 0) {
            $error = "Course code already exists in your department.";
        } else {
            // Insert the new course
            $insert_sql = "
                INSERT INTO courses (course_code, course_name, department, credit_hour, semester)
                VALUES ('$course_code', '$course_name', '$department', $credit_hour, '$semester')
            ";

            if (mysqli_query($conn, $insert_sql)) {
                $success = "Course added successfully to department: " . htmlspecialchars($department);

                // Clear form values after success
                $course_code = '';
                $course_name = '';
                $semester = '';
                $credit_hour = 3;
            } else {
                $error = "Failed to add course: " . mysqli_error($conn);
            }
        }
    }
}

?>

<h2>Add New Course to Department: <?= htmlspecialchars($department) ?></h2>

<?php if ($error): ?>
    <div style="color:red"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div style="color:green"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="POST" style="max-width: 400px;">
    <label for="course_code">Course Code:</label><br>
    <input type="text" id="course_code" name="course_code" required value="<?= htmlspecialchars($course_code ?? '') ?>"><br><br>

    <label for="course_name">Course Name:</label><br>
    <input type="text" id="course_name" name="course_name" required value="<?= htmlspecialchars($course_name ?? '') ?>"><br><br>

    <label for="credit_hour">Credit Hour:</label><br>
    <input type="number" id="credit_hour" name="credit_hour" min="1" max="10" value="<?= htmlspecialchars($credit_hour ?? 3) ?>"><br><br>

    <label for="semester">semester (optional):</label><br>
    <input type="text" id="semester" name="semester" value="<?= htmlspecialchars($batch ?? '') ?>"><br><br>

    <button type="submit">Add Course</button>
</form>

<p><a href="courses_list.php">Back to Course List</a></p>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']);
include __DIR__ . '/../includes/db.php';
$id = intval($_GET['id']);
mysqli_query($conn, "DELETE FROM courses WHERE id=$id");
header("Location: courses.php");
exit;
?>

<?php
session_start();

require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$success = '';

/* ===============================
   CHECK LOGIN
================================ */
$user_id = $_SESSION['user_id'] ?? 0;
$user_id = (int)$user_id;

if ($user_id <= 0) {
    die("<div style='color:red'>User not logged in.</div>");
}

/* ===============================
   GET DEPARTMENT
================================ */
$stmt = mysqli_prepare($conn, "SELECT department FROM department_heads WHERE user_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$dept_res = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

if (!$dept_res || mysqli_num_rows($dept_res) === 0) {
    die("<div style='color:red'>Department not found.</div>");
}

$dept_row = mysqli_fetch_assoc($dept_res);
<?php
session_start();

require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

$error = '';
$success = '';

/* ===============================
   CHECK LOGIN
================================ */
$user_id = $_SESSION['user_id'] ?? 0;
$user_id = (int)$user_id;

if ($user_id <= 0) {
    die("<div style='color:red'>User not logged in.</div>");
}

/* ===============================
   GET DEPARTMENT
================================ */
$stmt = mysqli_prepare($conn, "SELECT department FROM department_heads WHERE user_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$dept_res = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

if (!$dept_res || mysqli_num_rows($dept_res) === 0) {
    die("<div style='color:red'>Department not found.</div>");
}

$dept_row = mysqli_fetch_assoc($dept_res);
$department = $dept_row['department'];

/* ===============================
   GET COURSE ID
================================ */
$course_id = (int)($_GET['id'] ?? 0);
if ($course_id <= 0) {
    die("<div style='color:red'>Invalid course ID.</div>");
}

/* ===============================
   FETCH COURSE (OWN DEPARTMENT)
================================ */
$stmt = mysqli_prepare($conn, "SELECT * FROM courses WHERE id = ? AND department = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'is', $course_id, $department);
mysqli_stmt_execute($stmt);
$course_res = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

if (!$course_res || mysqli_num_rows($course_res) === 0) {
    die("<div style='color:red'>Course not found or access denied.</div>");
}

$course = mysqli_fetch_assoc($course_res);

/* ===============================
   HANDLE UPDATE
================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $course_code = strtoupper(trim($_POST['course_code'] ?? ''));
    $course_name = trim($_POST['course_name'] ?? '');
    $credit_hour = (int)($_POST['credit_hour'] ?? 0);
    $semester = trim($_POST['semester'] ?? '');

    if ($course_code === '' || $course_name === '') {
        $error = "Course code and name are required.";
    } elseif ($credit_hour < 1 || $credit_hour > 10) {
        $error = "Credit hour must be between 1 and 10.";
    } else {

        // Escape strings
        $course_code_s = mysqli_real_escape_string($conn, $course_code);
        $course_name_s = mysqli_real_escape_string($conn, $course_name);
        $semester_s = mysqli_real_escape_string($conn, $semester);

        // DUPLICATE CHECK
        $dup_stmt = mysqli_prepare($conn, "SELECT id FROM courses WHERE course_code = ? AND department = ? AND id != ? LIMIT 1");
        mysqli_stmt_bind_param($dup_stmt, 'ssi', $course_code_s, $department, $course_id);
        mysqli_stmt_execute($dup_stmt);
        mysqli_stmt_store_result($dup_stmt);
        $dup_count = mysqli_stmt_num_rows($dup_stmt);
        mysqli_stmt_close($dup_stmt);

        if ($dup_count > 0) {
            $error = "Another course with this code already exists.";
        } else {
            // Use safe concatenation for department (consistent with project pattern)
            $sql = "UPDATE courses SET course_code = '" . $course_code_s . "', course_name = '" . $course_name_s . "', credit_hour = $credit_hour, semester = '" . $semester_s . "' WHERE id = $course_id AND department = '" . mysqli_real_escape_string($conn, $department) . "'";

            if (mysqli_query($conn, $sql)) {
                $success = "Course updated successfully.";
                // Refresh data
                $course['course_code'] = $course_code;
                $course['course_name'] = $course_name;
                $course['credit_hour'] = $credit_hour;
                $course['semester'] = $semester;
            } else {
                $error = "Update failed: " . mysqli_error($conn);
            }
        }
    }
}
?>

<h2>Edit Course (<?= htmlspecialchars($department) ?>)</h2>

<?php if ($error): ?>
    <div style="color:red"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div style="color:green"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="POST" style="max-width:400px;">
    <label>Course Code</label><br>
    <input type="text" name="course_code" required
           value="<?= htmlspecialchars($course['course_code']) ?>"><br><br>

    <label>Course Name</label><br>
    <input type="text" name="course_name" required
           value="<?= htmlspecialchars($course['course_name']) ?>"><br><br>

    <label>Credit Hour</label><br>
    <input type="number" name="credit_hour" min="1" max="10"
           value="<?= htmlspecialchars($course['credit_hour']) ?>"><br><br>

    <label>Batch</label><br>
    <input type="text" name="semester"
           value="<?= htmlspecialchars($course['semester'] ?? '') ?>"><br><br>

    <label>Department</label><br>
    <input type="text" disabled value="<?= htmlspecialchars($department) ?>"><br><br>

    <button type="submit">Update Course</button>
</form>

<p><a href="courses_list.php">← Back to Course List</a></p>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

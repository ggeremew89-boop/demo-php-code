<?php
// courses_list.php

session_start();

require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

$user_id = $_SESSION['user_id'] ?? 0;
if ($user_id <= 0) {
    die("<div style='color:red'>User not logged in.</div>");
}

// Get department of logged-in department head
$stmt = mysqli_prepare($conn, "SELECT department FROM department_heads WHERE user_id = ?");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$dept_row = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$dept_row) {
    die("<div style='color:red'>Department not found for your user.</div>");
}
$department = $dept_row['department'];

// Pagination parameters
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$perPage = 15;
$offset = ($page - 1) * $perPage;

// Count total courses in this department
$stmt = mysqli_prepare($conn, "SELECT COUNT(*) FROM courses WHERE department = ?");
mysqli_stmt_bind_param($stmt, "s", $department);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $totalCourses);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

$totalPages = ceil($totalCourses / $perPage);

// Fetch courses for current page
$stmt = mysqli_prepare($conn, "SELECT id, course_code, course_name, credit_hour, semester FROM courses WHERE department = ? ORDER BY course_code ASC LIMIT ? OFFSET ?");
mysqli_stmt_bind_param($stmt, "sii", $department, $perPage, $offset);
mysqli_stmt_execute($stmt);
$courses_res = mysqli_stmt_get_result($stmt);
$courses = mysqli_fetch_all($courses_res, MYSQLI_ASSOC);
mysqli_stmt_close($stmt);
?>

<h2>Courses in Department: <?= htmlspecialchars($department) ?></h2>

<p><a href="courses_add.php">Add New Course</a></p>

<?php if (count($courses) === 0): ?>
    <p>No courses found in your department.</p>
<?php else: ?>
    <table border="1" cellpadding="5" cellspacing="0" style="width:100%; max-width:800px;">
        <thead>
            <tr>
                <th>Course Code</th>
                <th>Course Name</th>
                <th>Credit Hour</th>
                <th>semester</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($courses as $c): ?>
                <tr>
                    <td><?= htmlspecialchars($c['course_code']) ?></td>
                    <td><?= htmlspecialchars($c['course_name']) ?></td>
                    <td style="text-align:center;"><?= (int)$c['credit_hour'] ?></td>
                    <td><?= htmlspecialchars($c['semester']) ?></td>
                    <td>
                        <a href="courses_edit.php?id=<?= (int)$c['id'] ?>">Edit</a> |
                        <a href="courses_delete.php?id=<?= (int)$c['id'] ?>" onclick="return confirm('Delete this course?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <?php if ($totalPages > 1): ?>
        <p>Page:
        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <?php if ($p === $page): ?>
                <strong><?= $p ?></strong>
            <?php else: ?>
                <a href="?page=<?= $p ?>"><?= $p ?></a>
            <?php endif; ?>
        <?php endfor; ?>
        </p>
    <?php endif; ?>
<?php endif; ?>

<p><a href="dashboard_department_head.php">Back to Dashboard</a></p>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

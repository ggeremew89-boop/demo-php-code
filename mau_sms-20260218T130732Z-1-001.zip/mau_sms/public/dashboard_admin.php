<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin','admin','registrar']);
include __DIR__ . '/../includes/header.php';
?>
<h1>Admin Dashboard</h1>
<p>Welcome to the Mekdela Amba University Student Management System Admin Dashboard.</p>
<p>From here, you can manage users, departments, and view student registrations.</p>
<p>Please use the navigation menu to access different sections of the system.</p>
<p>Quick links: Manage students, instructors, courses, registrations, timetable, attendance and reports.</p>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']);
require_once __DIR__ . '/../includes/db.php';

// Check user_id is set
if (!isset($_SESSION['user_id'])) {
    // Not logged in or session expired - redirect to login or show error
    header('Location: /login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Prepare and execute query
$query = "SELECT dh.*, u.username FROM department_heads dh JOIN users u ON dh.user_id = u.id WHERE dh.user_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$dept_head = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

include __DIR__ . '/../includes/header.php';
?>

<h2>Department Head Dashboard</h2>

<?php if ($dept_head): ?>
    <p>Welcome, <strong><?php echo htmlspecialchars($dept_head['fname'] . ' ' . $dept_head['lname']); ?></strong> (<?php echo htmlspecialchars($dept_head['username']); ?>)</p>
    <p>Department: <strong><?php echo htmlspecialchars($dept_head['department']); ?></strong></p>
<?php else: ?>
    <p><strong>Error:</strong> Department head information not found.</p>
    <p>Please contact the administrator.</p>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>

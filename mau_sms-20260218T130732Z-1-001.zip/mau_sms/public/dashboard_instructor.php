<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['instructor']);
include __DIR__ . '/../includes/header.php';
?>
<h1>Instructor Dashboard</h1>
<p>Use the menu to upload results, view timetable and take attendance.</p>
<?php include __DIR__ . '/../includes/footer.php'; ?>

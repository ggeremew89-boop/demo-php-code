<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['registrar','superadmin','admin']);
include __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

// Basic counts for quick overview
$students_count = 0;
$instructors_count = 0;
$pending_regs = 0;

$r = mysqli_query($conn, "SELECT COUNT(*) AS c FROM students");
if ($r) $students_count = (int) mysqli_fetch_assoc($r)['c'];
$r = mysqli_query($conn, "SELECT COUNT(*) AS c FROM instructors");
if ($r) $instructors_count = (int) mysqli_fetch_assoc($r)['c'];
$r = mysqli_query($conn, "SELECT COUNT(*) AS c FROM registrations WHERE status!='registered'");
if ($r) $pending_regs = (int) mysqli_fetch_assoc($r)['c'];

?>

<h1>Registrar Dashboard</h1>

<p>Quick Overview</p>
<ul>
    <li><strong>Students:</strong> <?= $students_count ?></li>
    <li><strong>Instructors:</strong> <?= $instructors_count ?></li>
    <li><strong>Pending Registrations:</strong> <?= $pending_regs ?></li>
</ul>



<?php include __DIR__ . '/../includes/footer.php'; ?>

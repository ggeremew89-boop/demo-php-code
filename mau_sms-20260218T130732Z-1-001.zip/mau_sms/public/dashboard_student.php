<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['student']);
include __DIR__ . '/../includes/db.php';

$user_id = intval($_SESSION['user_id'] ?? 0);
$student_res = mysqli_query($conn, "SELECT * FROM students WHERE user_id = $user_id LIMIT 1");
$student = $student_res ? mysqli_fetch_assoc($student_res) : null;

$user = current_user();

include __DIR__ . '/../includes/header.php';
?>
<h1>Student Dashboard</h1>
<p>Welcome! Use the menu to register courses, view results, timetable </p>
<?php if ($student): ?>
    <p>Welcome, <strong><?php echo htmlspecialchars($student['fname'] . ' ' . $student['lname']); ?></strong> (<?php echo htmlspecialchars($user['username'] ?? ($student['student_number'] ?? '')); ?>)</p>
    <p>Department: <strong><?php echo htmlspecialchars($student['department']); ?></strong></p>
<?php else: ?>
    <p><strong>Error:</strong> Student information not found.</p>
    <p>Please contact the administrator.</p>
  
<?php endif; include __DIR__ . '/../includes/footer.php';
?>
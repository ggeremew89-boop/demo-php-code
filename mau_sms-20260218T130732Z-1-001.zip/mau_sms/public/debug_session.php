<?php
// Quick debug page to inspect session and domain links for the logged-in user
session_start();
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: text/html; charset=utf-8');
echo "<h2>Debug Session & User Links</h2>";
echo "<p><a href='index.php'>Back to index</a></p>";
echo "<pre style='white-space:pre-wrap;'>";
echo "SESSION:\n";
var_export($_SESSION);

$uid = intval($_SESSION['user_id'] ?? 0);
if ($uid) {
    echo "\n\nDB user row:\n";
    $r = mysqli_query($conn, "SELECT * FROM users WHERE id=$uid LIMIT 1");
    $u = $r ? mysqli_fetch_assoc($r) : null;
    var_export($u);

    echo "\n\ndepartment_heads row:\n";
    $r = mysqli_query($conn, "SELECT * FROM department_heads WHERE user_id=$uid LIMIT 1");
    var_export($r ? mysqli_fetch_assoc($r) : null);

    echo "\n\ninstructors row:\n";
    $r = mysqli_query($conn, "SELECT * FROM instructors WHERE user_id=$uid LIMIT 1");
    var_export($r ? mysqli_fetch_assoc($r) : null);

    echo "\n\nstudents row:\n";
    $r = mysqli_query($conn, "SELECT * FROM students WHERE user_id=$uid LIMIT 1");
    var_export($r ? mysqli_fetch_assoc($r) : null);

    echo "\n\nRoles computed from session: ";
    $roles = $_SESSION['roles'] ?? (isset($_SESSION['role']) ? array_map('trim', explode(',', $_SESSION['role'])) : []);
    var_export($roles);

} else {
    echo "\nNo logged-in user (no user_id in session).";
}
echo "</pre>";

?>
<?php
session_start();
require_once __DIR__.'/../includes/db.php';
echo '<pre>SESSION:'; var_dump($_SESSION);
$uid = intval($_SESSION['user_id'] ?? 0);
echo "\nUSER:\n"; $r = mysqli_query($conn,"SELECT * FROM users WHERE id=$uid LIMIT 1"); var_dump(mysqli_fetch_assoc($r));
echo "\nDEPARTMENT_HEAD:\n"; $r = mysqli_query($conn,"SELECT * FROM department_heads WHERE user_id=$uid LIMIT 1"); var_dump(mysqli_fetch_assoc($r));
echo "\nINSTRUCTOR:\n"; $r = mysqli_query($conn,"SELECT * FROM instructors WHERE user_id=$uid LIMIT 1"); var_dump(mysqli_fetch_assoc($r));
echo '</pre>';
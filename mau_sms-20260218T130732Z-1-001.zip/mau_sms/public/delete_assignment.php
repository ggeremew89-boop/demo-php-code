<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']);
require_once __DIR__ . '/../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assignment_id'])) {
    $assignment_id = intval($_POST['assignment_id']);
    if ($assignment_id) {
        $stmt = mysqli_prepare($conn, "DELETE FROM course_instructors WHERE id = ?");
        mysqli_stmt_bind_param($stmt, 'i', $assignment_id);
        if (mysqli_stmt_execute($stmt)) {
            header("Location: assign_teacher.php");
            exit;
        } else {
            die("Failed to delete assignment: " . mysqli_stmt_error($stmt));
        }
        mysqli_stmt_close($stmt);
    }
}
header("Location: assign_teacher.php");
exit;

<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin', 'admin', 'registrar']);
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Sanitize & trim inputs
    $code    = strtoupper(trim($_POST['department_code'] ?? ''));
    $name    = trim($_POST['department_name'] ?? '');
    $faculty = trim($_POST['faculty'] ?? '');

    /* =========================
       VALIDATION
    ========================= */

    if ($code === '' || $name === '' || $faculty === '') {
        $error = "All fields are required.";
    }
    elseif (!preg_match('/^[A-Z0-9_-]{2,10}$/', $code)) {
        $error = "Department code must be 2–10 characters (letters, numbers, - or _).";
    }
    elseif (strlen($name) < 3 || strlen($name) > 50) {
        $error = "Department name must be between 3 and 50 characters.";
    }
    elseif (strlen($faculty) < 3 || strlen($faculty) > 50) {
        $error = "Faculty name must be between 3 and 50 characters.";
    }
    else {
        /* =========================
           CHECK DUPLICATE CODE
        ========================= */
        $check = mysqli_prepare(
            $conn,
            "SELECT id FROM departments WHERE department_code = ? LIMIT 1"
        );
        mysqli_stmt_bind_param($check, 's', $code);
        mysqli_stmt_execute($check);
        mysqli_stmt_store_result($check);

        if (mysqli_stmt_num_rows($check) > 0) {
            $error = "Department code already exists.";
        } else {

            /* =========================
               INSERT DEPARTMENT
            ========================= */
            $stmt = mysqli_prepare(
                $conn,
                "INSERT INTO departments (department_code, department_name, faculty)
                 VALUES (?, ?, ?)"
            );
            mysqli_stmt_bind_param($stmt, 'sss', $code, $name, $faculty);

            if (mysqli_stmt_execute($stmt)) {
                $success = "Department added successfully.";
                // Clear form after success
                $code = $name = $faculty = '';
            } else {
                $error = "Database error. Please try again.";
            }
            mysqli_stmt_close($stmt);
        }
        mysqli_stmt_close($check);
    }
}
?>

<div class="container" style="max-width:700px; margin:40px auto;">

    <h2>Add Department</h2>

    <?php if ($error): ?>
        <div class="error" style="color:#b30000; margin-bottom:15px;">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success" style="color:#006600; margin-bottom:15px;">
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <form method="POST" novalidate>

        <label>Department Code</label><br>
        <input type="text" name="department_code"
               value="<?= htmlspecialchars($code ?? '') ?>"
               maxlength="10" required placeholder="CS_11"><br><br>

        <label>Department Name</label><br>
        <input type="text" name="department_name"
               value="<?= htmlspecialchars($name ?? '') ?>"
               maxlength="50" required placeholder="Computer Science"><br><br>

        <label>Faculty</label><br>
        <input type="text" name="faculty"
               value="<?= htmlspecialchars($faculty ?? '') ?>"
               maxlength="50" required placeholder="Engineering"><br><br>

        <button type="submit">Add Department</button>

    </form>

    <br>
    <a href="departments.php">← Back to Departments</a>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

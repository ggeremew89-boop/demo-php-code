<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin','admin','registrar']);
include __DIR__ . '/../includes/db.php';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    die('Invalid department ID.');
}

$stmt = mysqli_prepare($conn, "DELETE FROM departments WHERE id = ?");
mysqli_stmt_bind_param($stmt, 'i', $id);
if (mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    header("Location: departments.php?msg=deleted");
    exit;
} else {
    $error = "Failed to delete department: " . mysqli_stmt_error($stmt);
    mysqli_stmt_close($stmt);
    die($error);
}

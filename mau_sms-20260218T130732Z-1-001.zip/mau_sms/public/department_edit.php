<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin','admin','registrar']);
include __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$error = '';
$success = '';

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    die('Invalid department ID.');
}

// Fetch current department data
$stmt = mysqli_prepare($conn, "SELECT * FROM departments WHERE id = ?");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$department = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$department) {
    die('Department not found.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = trim($_POST['department_code']);
    $name = trim($_POST['department_name']);
    $faculty = trim($_POST['faculty']);

    if (!$code || !$name || !$faculty) {
        $error = "All fields are required.";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE departments SET department_code = ?, department_name = ?, faculty = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, 'sssi', $code, $name, $faculty, $id);
        if (mysqli_stmt_execute($stmt)) {
            $success = "Department updated successfully.";
            // Refresh current data after update
            $department['department_code'] = $code;
            $department['department_name'] = $name;
            $department['faculty'] = $faculty;
        } else {
            $error = "Database error: " . mysqli_stmt_error($stmt);
        }
        mysqli_stmt_close($stmt);
    }
}
?>

<h2>Edit Department</h2>

<?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if ($success): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="POST">
    <label>Department Code:</label><br>
    <input type="text" name="department_code" value="<?= htmlspecialchars($department['department_code']) ?>" required><br><br>

    <label>Department Name:</label><br>
    <input type="text" name="department_name" value="<?= htmlspecialchars($department['department_name']) ?>" required><br><br>

    <label>Faculty:</label><br>
    <input type="text" name="faculty" value="<?= htmlspecialchars($department['faculty']) ?>" required><br><br>

    <button type="submit">Update Department</button>
</form>

<a href="departments.php">Back to Departments</a>

<?php include __DIR__ . '/../includes/footer.php'; ?>

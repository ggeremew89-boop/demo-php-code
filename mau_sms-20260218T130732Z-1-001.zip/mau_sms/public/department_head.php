<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin', 'admin', 'registrar']);
include __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';
 
// If current user is a department_head, fetch their department for validation/UI
$current_user_department = null;
$current_user_id = $_SESSION['user_id'] ?? 0;
if (has_role('department_head')) {
    $dq = mysqli_prepare($conn, "SELECT department FROM department_heads WHERE user_id=? LIMIT 1");
    mysqli_stmt_bind_param($dq, 'i', $current_user_id);
    mysqli_stmt_execute($dq);
    $dr = mysqli_stmt_get_result($dq);
    $drow = mysqli_fetch_assoc($dr);
    mysqli_stmt_close($dq);
    $current_user_department = $drow['department'] ?? null;
}
function e($str) {
    return htmlspecialchars($str, ENT_QUOTES);
}

// Validate string input (trimmed, non-empty, max length)
function validate_str($input, $maxLength = 255) {
    $input = trim($input);
    if ($input === '' || mb_strlen($input) > $maxLength) {
        return false;
    }
    return $input;
}

// Validate ID (positive integer)
function validate_id($id) {
    if (!filter_var($id, FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]])) {
        return false;
    }
    return (int)$id;
}

/* =========================
   DELETE DEPARTMENT HEAD
========================= */
if (isset($_GET['delete_id'])) {
    $delete_id = validate_id($_GET['delete_id']);
    if ($delete_id === false) {
        echo "<div class='error'>Invalid ID.</div>";
    } else {
        $res = mysqli_query($conn, "SELECT user_id FROM department_heads WHERE id=$delete_id LIMIT 1");
        if ($res && mysqli_num_rows($res) === 1) {
            $user_id = (int) mysqli_fetch_assoc($res)['user_id'];
            mysqli_query($conn, "DELETE FROM department_heads WHERE id=$delete_id");
            mysqli_query($conn, "DELETE FROM users WHERE id=$user_id");
            echo "<div class='success'>Department Head deleted successfully.</div>";
        } else {
            echo "<div class='error'>Department Head not found.</div>";
        }
    }
}

/* =========================
   EDIT DEPARTMENT HEAD
========================= */
if (isset($_POST['edit_id'])) {
    $edit_id = validate_id($_POST['edit_id']);
    $fname = validate_str($_POST['fname'], 80);
    $lname = validate_str($_POST['lname'], 80);
    $department = validate_str($_POST['department'], 120);
    // Ensure department exists in departments table
    if ($department) {
        $chk_dep = mysqli_prepare($conn, "SELECT id FROM departments WHERE department_name=? LIMIT 1");
        mysqli_stmt_bind_param($chk_dep, 's', $department);
        mysqli_stmt_execute($chk_dep);
        mysqli_stmt_store_result($chk_dep);
        if (mysqli_stmt_num_rows($chk_dep) === 0) {
            $department = false; // mark invalid
        }
        mysqli_stmt_close($chk_dep);
    }
    $username = validate_str($_POST['username'], 80);
    $password_plain = trim($_POST['password'] ?? '');
    // Department heads must also be instructors in the system.
    $is_teacher = true; // enforce instructor association

    // Role includes 'instructor' so other pages that check for instructor will work
    $role = 'department_head,instructor';

    if ($edit_id === false || !$fname || !$lname || !$department || !$username) {
        echo "<div class='error'>All fields are required and must be valid.</div>";
    } else {
        // If current user is a department_head, restrict editing to their own department
        if (has_role('department_head') && $current_user_department && $department !== $current_user_department) {
            echo "<div class='error'>You may only edit department heads within your own department.</div>";
        } else {
            // Check if another department head already exists for this department
            $dep_check = mysqli_query($conn,
                "SELECT id FROM department_heads 
                 WHERE department='".mysqli_real_escape_string($conn,$department)."' 
                 AND id!=$edit_id LIMIT 1"
            );

            if (mysqli_num_rows($dep_check) > 0) {
                echo "<div class='error'>This department already has a Department Head.</div>";
            } else {
                $res = mysqli_query($conn, "SELECT user_id FROM department_heads WHERE id=$edit_id LIMIT 1");
                if (!$res || mysqli_num_rows($res) !== 1) {
                    echo "<div class='error'>Department Head not found.</div>";
                } else {
                    $user_id = (int) mysqli_fetch_assoc($res)['user_id'];

                    $check = mysqli_query($conn,
                        "SELECT id FROM users 
                         WHERE username='".mysqli_real_escape_string($conn,$username)."' 
                         AND id!=$user_id LIMIT 1"
                    );

                    if (mysqli_num_rows($check) > 0) {
                        echo "<div class='error'>Username already exists.</div>";
                    } else {
                        if ($password_plain !== '') {
                            $hash = password_hash($password_plain, PASSWORD_DEFAULT);
                            $stmt = mysqli_prepare($conn,
                                "UPDATE users SET username=?, password=?, role=? WHERE id=?"
                            );
                            mysqli_stmt_bind_param($stmt, "sssi", $username, $hash, $role, $user_id);
                        } else {
                            $stmt = mysqli_prepare($conn,
                                "UPDATE users SET username=?, role=? WHERE id=?"
                            );
                            mysqli_stmt_bind_param($stmt, "ssi", $username, $role, $user_id);
                        }
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);

                        mysqli_query($conn,
                            "UPDATE department_heads SET
                                fname='".mysqli_real_escape_string($conn,$fname)."',
                                lname='".mysqli_real_escape_string($conn,$lname)."',
                                department='".mysqli_real_escape_string($conn,$department)."'
                             WHERE id=$edit_id"
                        );

                        // Ensure an instructors row exists for this user
                        $ins_check = mysqli_prepare($conn, "SELECT id FROM instructors WHERE user_id=? LIMIT 1");
                        mysqli_stmt_bind_param($ins_check, 'i', $user_id);
                        mysqli_stmt_execute($ins_check);
                        mysqli_stmt_store_result($ins_check);
                        $has_instructor = mysqli_stmt_num_rows($ins_check) > 0;
                        mysqli_stmt_close($ins_check);

                        if (!$has_instructor) {
                            $instr_code = 'DH'. $user_id;
                            $ins_instr = mysqli_prepare($conn,
                                "INSERT INTO instructors (user_id, instructor_code, fname, lname, department) VALUES (?,?,?,?,?)"
                            );
                            mysqli_stmt_bind_param($ins_instr, 'issss', $user_id, $instr_code, $fname, $lname, $department);
                            mysqli_stmt_execute($ins_instr);
                            mysqli_stmt_close($ins_instr);
                        } else {
                            // update instructor info to match department head
                            mysqli_query($conn,
                                "UPDATE instructors SET fname='".mysqli_real_escape_string($conn,$fname)."', lname='".mysqli_real_escape_string($conn,$lname)."', department='".mysqli_real_escape_string($conn,$department)."' WHERE user_id=$user_id"
                            );
                        }
                        echo "<div class='success'>Department Head updated successfully.</div>";
                    }
                }
            }
        }
    }
}

/* =========================
   ADD DEPARTMENT HEAD
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['edit_id'])) {
    // New flow: require selecting an existing instructor account to become Department Head
    $instructor_user_id = validate_id($_POST['instructor_user_id'] ?? '');
    $department = validate_str($_POST['department'], 120);
    if ($department) {
        $chk_dep = mysqli_prepare($conn, "SELECT id FROM departments WHERE department_name=? LIMIT 1");
        mysqli_stmt_bind_param($chk_dep, 's', $department);
        mysqli_stmt_execute($chk_dep);
        mysqli_stmt_store_result($chk_dep);
        if (mysqli_stmt_num_rows($chk_dep) === 0) {
            $department = false; // mark invalid
        }
        mysqli_stmt_close($chk_dep);
    }
    $fname = validate_str($_POST['fname'] ?? '', 80);
    $lname = validate_str($_POST['lname'] ?? '', 80);

    if ($instructor_user_id === false || !$department) {
        echo "<div class='error'>Please choose a valid instructor and department.</div>";
    } else {
        // If current user is a department_head, restrict adding to their own department
        if (has_role('department_head') && $current_user_department && $department !== $current_user_department) {
            echo "<div class='error'>You may only add a Department Head for your own department.</div>";
        } else {
            // Check department uniqueness
            $dep_check = mysqli_prepare($conn, "SELECT id FROM department_heads WHERE department=? LIMIT 1");
            mysqli_stmt_bind_param($dep_check, 's', $department);
            mysqli_stmt_execute($dep_check);
            mysqli_stmt_store_result($dep_check);
            if (mysqli_stmt_num_rows($dep_check) > 0) {
                mysqli_stmt_close($dep_check);
                echo "<div class='error'>This department already has a Department Head.</div>";
            } else {
                mysqli_stmt_close($dep_check);

                // Verify the selected user is an instructor
                $chk_instr = mysqli_prepare($conn, "SELECT id, fname, lname FROM instructors WHERE user_id=? LIMIT 1");
                mysqli_stmt_bind_param($chk_instr, 'i', $instructor_user_id);
                mysqli_stmt_execute($chk_instr);
                $res_instr = mysqli_stmt_get_result($chk_instr);
                $instr_row = mysqli_fetch_assoc($res_instr);
                mysqli_stmt_close($chk_instr);

                if (!$instr_row) {
                    echo "<div class='error'>Selected user is not an instructor.</div>";
                } else {
                    // Use instructor's name if not provided
                    if (!$fname) $fname = $instr_row['fname'] ?? '';
                    if (!$lname) $lname = $instr_row['lname'] ?? '';

                    // Ensure the user isn't already a department head
                    $chk_dh = mysqli_prepare($conn, "SELECT id FROM department_heads WHERE user_id=? LIMIT 1");
                    mysqli_stmt_bind_param($chk_dh, 'i', $instructor_user_id);
                    mysqli_stmt_execute($chk_dh);
                    mysqli_stmt_store_result($chk_dh);
                    if (mysqli_stmt_num_rows($chk_dh) > 0) {
                        mysqli_stmt_close($chk_dh);
                        echo "<div class='error'>Selected instructor is already a Department Head.</div>";
                    } else {
                        mysqli_stmt_close($chk_dh);

                        // Insert department_head record
                        $ins = mysqli_prepare($conn, "INSERT INTO department_heads (user_id,fname,lname,department) VALUES (?,?,?,?)");
                        mysqli_stmt_bind_param($ins, 'isss', $instructor_user_id, $fname, $lname, $department);
                        if (!mysqli_stmt_execute($ins)) {
                            $err = mysqli_stmt_error($ins);
                            mysqli_stmt_close($ins);
                            echo "<div class='error'>Failed to add Department Head: " . htmlspecialchars($err) . "</div>";
                        } else {
                            mysqli_stmt_close($ins);

                            // Add 'department_head' to user's role if not present
                            $u = mysqli_prepare($conn, "SELECT role FROM users WHERE id=? LIMIT 1");
                            mysqli_stmt_bind_param($u, 'i', $instructor_user_id);
                            mysqli_stmt_execute($u);
                            $resu = mysqli_stmt_get_result($u);
                            $user_row = mysqli_fetch_assoc($resu);
                            mysqli_stmt_close($u);

                            $current_roles = array_map('trim', explode(',', $user_row['role'] ?? ''));
                            if (!in_array('department_head', $current_roles)) {
                                $current_roles[] = 'department_head';
                                $new_role = implode(',', array_unique(array_filter($current_roles)));
                                $upd = mysqli_prepare($conn, "UPDATE users SET role=? WHERE id=?");
                                mysqli_stmt_bind_param($upd, 'si', $new_role, $instructor_user_id);
                                mysqli_stmt_execute($upd);
                                mysqli_stmt_close($upd);
                            }

                            echo "<div class='success'>Department Head added successfully.</div>";
                        }
                    }
                }
            }
        }
    }
}

/* =========================
   FETCH DATA
========================= */
$res = mysqli_query($conn,
    "SELECT dh.id, dh.fname, dh.lname, dh.department, u.username
     FROM department_heads dh
     JOIN users u ON dh.user_id = u.id
     ORDER BY dh.id DESC"
);

// Load instructors for the Add form (user must pick an existing instructor)
$instructors_res = mysqli_query($conn,
    "SELECT i.user_id, i.instructor_code, i.fname, i.lname, u.username
     FROM instructors i JOIN users u ON i.user_id = u.id
     ORDER BY i.fname, i.lname"
);

$edit_row = null;
if (isset($_GET['edit_id'])) {
    $id = validate_id($_GET['edit_id']);
    if ($id !== false) {
        $r = mysqli_query($conn,
            "SELECT dh.*, u.username, u.role 
             FROM department_heads dh
             JOIN users u ON dh.user_id = u.id
             WHERE dh.id=$id LIMIT 1"
        );
        $edit_row = mysqli_fetch_assoc($r);
    }
}

// Load departments for select inputs
$departments = [];
$dep_res = mysqli_query($conn, "SELECT department_name FROM departments ORDER BY department_name");
while ($d = mysqli_fetch_assoc($dep_res)) {
    $departments[] = $d['department_name'];
}
mysqli_free_result($dep_res);
?>

<h2>Department Heads</h2>
<a class="btn" onclick="document.getElementById('addForm').style.display='block'">+ Add Department Head</a>

<table border="1" width="100%" style="margin-top:10px">
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Department</th>
    <th>Username</th>
    <th>Actions</th>
</tr>
<?php while ($row = mysqli_fetch_assoc($res)): ?>
<tr>
    <td><?= e($row['id']) ?></td>
    <td><?= e($row['fname'].' '.$row['lname']) ?></td>
    <td><?= e($row['department']) ?></td>
    <td><?= e($row['username']) ?></td>
    <td>
        <a href="?edit_id=<?= e($row['id']) ?>">Edit</a> |
        <a href="?delete_id=<?= e($row['id']) ?>" onclick="return confirm('Delete?')">Delete</a>
    </td>
</tr>
<?php endwhile; ?>
</table>

<div id="addForm" style="display:<?= $edit_row ? 'block':'none' ?>;margin-top:20px">
<h3><?= $edit_row ? 'Edit' : 'Add' ?> Department Head</h3>

<form method="POST">
<?php if ($edit_row): ?>
<input type="hidden" name="edit_id" value="<?= e($edit_row['id']) ?>">
<?php endif; ?>

    <?php if (!$edit_row): ?>
    <label for="instructor_user_id">Choose existing Instructor:</label><br>
    <select name="instructor_user_id" id="instructor_user_id" required>
        <option value="">-- Select Instructor --</option>
        <?php while ($ins = mysqli_fetch_assoc($instructors_res)): ?>
            <option value="<?= (int)$ins['user_id'] ?>"><?= e($ins['username']) ?> - <?= e($ins['fname'].' '.$ins['lname']) ?></option>
        <?php endwhile; ?>
    </select><br><br>

    <label>First Name (optional, will use instructor name if blank)</label><br>
    <input name="fname" placeholder="First Name" value=""><br><br>
    <label>Last Name (optional)</label><br>
    <input name="lname" placeholder="Last Name" value=""><br><br>
    <label>Department</label><br>
    <?php if (has_role('department_head') && $current_user_department): ?>
        <input type="hidden" name="department" value="<?= e($current_user_department) ?>">
        <select disabled>
            <option><?= e($current_user_department) ?></option>
        </select><br><br>
    <?php else: ?>
        <select name="department" required>
            <option value="">-- Department --</option>
            <?php foreach($departments as $dname): ?>
                <option value="<?= e($dname) ?>"><?= e($dname) ?></option>
            <?php endforeach; ?>
        </select><br><br>
    <?php endif; ?>

    <button type="submit">Add</button>
<?php else: ?>
    <input name="fname" placeholder="First Name" required value="<?= e($edit_row['fname'] ?? '') ?>"><br><br>
    <input name="lname" placeholder="Last Name" required value="<?= e($edit_row['lname'] ?? '') ?>"><br><br>
    <label>Department</label><br>
    <?php if (has_role('department_head') && $current_user_department): ?>
        <input type="hidden" name="department" value="<?= e($current_user_department) ?>">
        <select disabled>
            <option><?= e($current_user_department) ?></option>
        </select><br><br>
    <?php else: ?>
        <select name="department" required>
            <option value="">-- Department --</option>
            <?php foreach($departments as $dname): ?>
                <option value="<?= e($dname) ?>" <?= (isset($edit_row['department']) && $edit_row['department']===$dname)?'selected':'' ?>><?= e($dname) ?></option>
            <?php endforeach; ?>
        </select><br><br>
    <?php endif; ?>

    <input name="username" placeholder="Username" required value="<?= e($edit_row['username'] ?? '') ?>"><br><br>
    <input type="password" name="password" placeholder="<?= $edit_row ? 'New Password (optional)' : 'Password' ?>" <?= $edit_row ? '' : 'required' ?>><br><br>

    <button type="submit"><?= $edit_row ? 'Update' : 'Add' ?></button>
<?php endif; ?>
</form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

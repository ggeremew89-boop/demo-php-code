<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin','admin','registrar']);
include __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$q = "SELECT * FROM departments ORDER BY id DESC";
$res = mysqli_query($conn, $q);

if (!$res) {
    die("SQL Error: " . mysqli_error($conn));
}
?>
<h2>Departments</h2>
<a class="btn" href="department_add.php">+ Add Department</a>

<table class="table">
<tr>
    <th>ID</th>
    <th>Dept Code</th>
    <th>Department Name</th>
    <th>Faculty</th>
    <th>Actions</th>
</tr>

<?php while($d = mysqli_fetch_assoc($res)): ?>
<tr>
    <td><?php echo $d['id']; ?></td>
    <td><?php echo htmlspecialchars($d['department_code']); ?></td>
    <td><?php echo htmlspecialchars($d['department_name']); ?></td>
    <td><?php echo htmlspecialchars($d['faculty']); ?></td>
    <td>
        <a href="department_edit.php?id=<?php echo $d['id']; ?>">Edit</a> |
        <a href="department_delete.php?id=<?php echo $d['id']; ?>" onclick="return confirm('Delete this department?');">Delete</a>
    </td>
</tr>
<?php endwhile; ?>

</table>

<?php include __DIR__ . '/../includes/footer.php'; ?>

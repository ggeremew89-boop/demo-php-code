<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

$message = '';
$step = 1; // 1: enter username, 2: enter new password if superadmin

if (isset($_POST['check_user'])) {
    $username = trim($_POST['username']);
    $username_q = mysqli_real_escape_string($conn, $username);
    $res = mysqli_query($conn, "SELECT id, role FROM users WHERE username='$username_q' LIMIT 1");

    if ($res && mysqli_num_rows($res) === 1) {
        $user = mysqli_fetch_assoc($res);
        $_SESSION['reset_user_id'] = $user['id'];
        if ($user['role'] === 'superadmin') {
            $step = 2;
        } else {
            $message = "Please contact admin for password reset.";
        }
    } else {
        $message = "User not found.";
    }
} elseif (isset($_POST['reset_password'])) {
    if (isset($_SESSION['reset_user_id'])) {
        $new_username = trim($_POST['new_username']);
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        if ($new_password === $confirm_password) {
            // Check if new username is unique
            $new_username_q = mysqli_real_escape_string($conn, $new_username);
            $res = mysqli_query($conn, "SELECT id FROM users WHERE username='$new_username_q' AND id != {$_SESSION['reset_user_id']} LIMIT 1");
            if ($res && mysqli_num_rows($res) === 0) {
                $hash = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = mysqli_prepare($conn, "UPDATE users SET username=?, password=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, 'ssi', $new_username, $hash, $_SESSION['reset_user_id']);
                if (mysqli_stmt_execute($stmt)) {
                    $message = "Username and password have been updated successfully.";
                    unset($_SESSION['reset_user_id']);
                } else {
                    $message = "Error updating user.";
                }
                mysqli_stmt_close($stmt);
            } else {
                $message = "Username already exists.";
                $step = 2;
            }
        } else {
            $message = "Passwords do not match.";
            $step = 2;
        }
    } else {
        $message = "Session expired. Please try again.";
    }
}

include __DIR__ . '/../includes/header.php';
?>

<div class="login-box">
    <img src="../assets/image/bb.jfif" alt="mm">
    <h2>Forgot Password</h2>
    <?php if (!empty($message)) : ?>
        <div class="error"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>
    <?php if ($step === 1) : ?>
        <form method="POST" action="">
            <input name="username" placeholder="Username" required autofocus>
            <button type="submit" name="check_user">Check User</button>
        </form>
    <?php elseif ($step === 2) : ?>
        <form method="POST" action="">
            <input name="new_username" placeholder="New Username" required>
            <input name="new_password" type="password" placeholder="New Password" required>
            <input name="confirm_password" type="password" placeholder="Confirm New Password" required>
            <button type="submit" name="reset_password">Update User</button>
        </form>
    <?php endif; ?>
    <a href="login.php">Back to Login</a>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
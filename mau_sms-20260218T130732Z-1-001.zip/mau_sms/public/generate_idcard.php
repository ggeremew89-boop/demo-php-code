<?php
// generate_idcard.php

session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    die("You must be logged in to generate your ID card.");
}

require_once __DIR__ . '/../includes/db.php';  // adjust path to your db connection file
require_once __DIR__ . '/../includes/vendor/fpdf.php'; // FPDF library

$user_id = intval($_SESSION['user_id']);

// Fetch student info from DB
$stmt = mysqli_prepare($conn, "SELECT fname, lname, student_number, department FROM students WHERE user_id = ?");
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$student = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$student) {
    die("Student record not found.");
}

// Prepare student info for ID card
$student_name = trim($student['fname'] . ' ' . $student['lname']);
$student_no = $student['student_number'];
$department = $student['department'];

// Generate card number or fetch from database if you have a separate card number table
$card_number = 'MAU-' . strtoupper($student_no);

// Create PDF (ID card size: 85.6mm x 54mm)
$pdf = new FPDF('P', 'mm', array(85.6, 54));
$pdf->AddPage();
$pdf->SetAutoPageBreak(false);

// Draw border
$pdf->Rect(2, 2, 81.6, 50, 'D');

// University title
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetXY(4, 4);
$pdf->Cell(0, 6, 'Mekdela Amba University', 0, 1, 'C');

// Subtitle
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(0, 5, 'Student ID Card', 0, 1, 'C');

// Photo placeholder rectangle and image
$photo_path = __DIR__ . '/../assets/images/default-photo.png';
$pdf->Rect(6, 18, 22, 26);
if (file_exists($photo_path)) {
    $pdf->Image($photo_path, 7, 19, 20, 24);
}

// Student details text
$pdf->SetXY(34, 18);
$pdf->SetFont('Arial', 'B', 9);
$pdf->Cell(0, 5, $student_name, 0, 1);
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(0, 5, 'No: ' . $student_no, 0, 1);
$pdf->Cell(0, 5, 'Dept: ' . $department, 0, 1);
$pdf->Cell(0, 5, 'Card#: ' . $card_number, 0, 1);

// Validity date
$pdf->SetY(48);
$pdf->SetFont('Arial', '', 6);
$pdf->Cell(0, 4, 'Valid: ' . date('Y'), 0, 1, 'C');

// Output PDF inline in browser
$pdf->Output('I', "MAU_ID_{$student_no}.pdf");
exit;
?>

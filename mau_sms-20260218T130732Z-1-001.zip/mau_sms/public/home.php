<?php
include '../includes/header.php';
?>

<div class="home-container">
    <section class="hero">
        <img src="../assets/image/ss.jfif" alt="Mekdela Amba University" class="hero-image">
        <div class="hero-overlay">
            <div>
                <div class="hero-title">Mekdela Amba University</div>
                <div class="hero-sub">Student Management System — empowering academic administration, simplifying
                    registrations, tracking results, and helping students and staff collaborate efficiently.</div>
                <a class="cta" href="/mau_sms/public/register_department_courses.php">Register Courses</a>
            </div>
        </div>
    </section>

    <h2>About the System</h2>
    <p>
        This Student Management System provides a simple, lightweight interface for managing students,
        courses, instructors and results at Mekdela Amba University. It is designed to be fast, responsive,
        and easy to use on both desktop and mobile devices.
    </p>

    <h2>University At a Glance</h2>
    <p>
        Mekdela Amba University is committed to excellence in teaching, research and community service.
        The university offers a range of undergraduate and postgraduate programs across multiple faculties.
    </p>

    <div class="media-section">
        <img src="../assets/image/i1.jfif" alt="Campus 1" class="home-image" /><br>

        <img src="../assets/image/i3.jfif" alt="Campus 2" class="home-image" /><br>
        <img src="../assets/image/i4.jfif" alt="Campus 3" class="home-image" /><br>
        <img src="../assets/image/i2.jfif" alt="Students" class="home-image" /><br>
    </div>
</div>


<?php
include '../includes/footer.php';
?>

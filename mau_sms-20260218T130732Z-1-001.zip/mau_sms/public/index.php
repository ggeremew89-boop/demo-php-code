<?php
// public/index.php
session_start();
require_once __DIR__ . '/../includes/db.php';

if(isset($_POST['login'])){
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $username_q = mysqli_real_escape_string($conn, $username);
    $res = mysqli_query($conn, "SELECT * FROM users WHERE username='$username_q' LIMIT 1");
    if($res && mysqli_num_rows($res) == 1){
        $user = mysqli_fetch_assoc($res);
        if(password_verify($password, $user['password'])){
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            // Keep legacy string role for compatibility but also expose an array of roles
            $_SESSION['role'] = $user['role'];
            $_SESSION['roles'] = array_map('trim', explode(',', $user['role']));
            // set an active role (defaults to the first role)
            $_SESSION['active_role'] = $_SESSION['roles'][0] ?? null;

            // Redirect based on primary role (first in list) for UX
            $primary = $_SESSION['roles'][0] ?? '';
            if($primary == 'student') header("Location: dashboard_student.php");
            elseif($primary == 'instructor') header("Location: dashboard_instructor.php");
            elseif($primary == 'department_head') header("Location: dashboard_department_head.php");
            elseif(in_array($primary, ['admin','superadmin'])) header("Location: dashboard_admin.php");
            elseif($primary == 'registrar') header("Location: dashboard_registrar.php");
            else header("Location: home.php");
            exit;
        } else {
            $error = "Invalid credentials.";
        }
    } else {
        $error = "User not found.";
    }
}


header("Location: login.php");
exit;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>MAU Student Management System</title>
    <link rel="stylesheet" href="../assets/css/style.css" />
    <style>
        body {
            font-family: Arial, sans-serif; 
            background: #b61717ff; 
            margin: 0; 
            padding: 0; 
            color: #333;
        }
        .nav {
            background-color: #003366; 
            color: white; 
            padding: 1rem 2rem;
            display: flex; 
            justify-content: space-between; 
            align-items: center;
        }
        .nav a {
            color: white; 
            margin-left: 1rem; 
            text-decoration: none; 
            font-weight: bold;
        }
        .nav a:hover {
            text-decoration: underline;
        }
        .container {
            max-width: 900px; 
            margin: 2rem auto; 
            padding: 1rem; 
            background: green; 
            border-radius: 8px; 
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
        }
        h1, h2 {
            color: #003366;
        }
        .login-box {
            max-width: 360px; 
            margin: 2rem auto;
            background: #8b1919ff; 
            padding: 20px; 
            border-radius: 6px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .login-box input, .login-box button {
            width: 100%; 
            padding: 10px; 
            margin: 8px 0; 
            border-radius: 4px; 
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        .login-box button {
            background-color: #003366; 
            color: white; 
            border: none; 
            cursor: pointer;
            font-weight: bold;
        }
        .login-box button:hover {
            background-color: #00509e;
        }
        .error {
            background:#fdecea; 
            border:1px solid #f5b5b5; 
            color:#8a1c1c; 
            padding:8px; 
            margin:8px 0;
        }
        .footer {
            text-align: center; 
            padding: 1rem; 
            margin-top: 2rem; 
            font-size: 0.9rem; 
            color: #777; 
            border-top: 1px solid #ccc;
        }
        .section {
            margin-bottom: 3rem;
        }
    </style>
</head>
<body>
<div class="nav">
    <div><strong>MAU Student Management System</strong></div>
    v>
</div>

<div class="container">
    <section id="about" class="section">
        <h1>About Mekdela Amba University</h1>
        <p>Mekdela Amba University is dedicated to providing quality education, fostering research, and serving the community. Our Student Management System streamlines academic and administrative processes to support students, instructors, and staff effectively.</p>
        <p>Founded in Ethiopia, MAU continues to grow and innovate in education technology to meet the needs of our diverse academic community.</p>
    </section>

    <section id="contact" class="section">
        <h2>Contact Us</h2>
        <p><strong>Address:</strong> Mekdela Amba University Campus, Ethiopia</p>
        <p><strong>Phone:</strong> +251 123 456 789</p>
        <p><strong>Email:</strong> info@mau.edu.et</p>
        <p><strong>Office Hours:</strong> Monday - Friday, 8 AM - 5 PM</p>
    </section>

    <section id="login" class="section">
        <div class="login-box">
            <h2>Login to MAU SMS</h2>
            <?php if(isset($error)): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            <form method="POST" action="#login">
                <input name="username" placeholder="Username" required autofocus>
                <input name="password" type="password" placeholder="Password" required>
                <button type="submit" name="login">Login</button>
            </form>
            <p>Default superadmin: <code>admin</code> / <code>admin123</code></p>
        </div>
    </section>
</div>

<div class="footer">
    &copy; 2025 Mekdela Amba University - Student Management System
</div>
</body>
</html>

<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin','admin']);
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$id = $_GET['id'] ?? null;
if (!$id) die("Instructor ID missing.");

$stmt = mysqli_prepare($conn, "SELECT * FROM instructors WHERE id=?");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$ins = mysqli_fetch_assoc($res);
mysqli_stmt_close($stmt);

if (!$ins) die("Instructor not found.");

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $code = $_POST['instructor_code'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $department = $_POST['department'];

    $upd = mysqli_prepare($conn,
        "UPDATE instructors SET
        instructor_code=?, fname=?, lname=?, department=?
        WHERE id=?"
    );

    mysqli_stmt_bind_param($upd, 'ssssi',
        $code, $fname, $lname, $department, $id
    );

    if (mysqli_stmt_execute($upd)) {
        $success = "Instructor updated successfully.";
    } else {
        $error = mysqli_stmt_error($upd);
    }
    mysqli_stmt_close($upd);
}
?>

<h2>Edit Instructor</h2>
<?php if($error): ?><div style="color:red"><?= $error ?></div><?php endif; ?>
<?php if($success): ?><div style="color:green"><?= $success ?></div><?php endif; ?>

<form method="POST">
Instructor Code<br><input name="instructor_code" value="<?= $ins['instructor_code'] ?>"><br><br>
First Name<br><input name="fname" value="<?= $ins['fname'] ?>"><br><br>
Last Name<br><input name="lname" value="<?= $ins['lname'] ?>"><br><br>
Department<br><input name="department" value="<?= $ins['department'] ?>"><br><br>
<button type="submit">Update</button>
</form>

<?php include __DIR__ . '/../includes/footer.php'; ?>

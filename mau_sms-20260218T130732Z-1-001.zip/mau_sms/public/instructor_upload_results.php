<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['instructor']);
include __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$user_id = $_SESSION['user_id'] ?? 0;

/* =========================
   FETCH INSTRUCTOR
========================= */
$stmt = mysqli_prepare($conn, "SELECT id, department FROM instructors WHERE user_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $instructor_id, $department);
if (!mysqli_stmt_fetch($stmt)) {
    die("<div class='error'>Instructor record not found.</div>");
}
mysqli_stmt_close($stmt);

/* =========================
   FETCH INSTRUCTOR COURSES
========================= */
$stmt = mysqli_prepare($conn, "
    SELECT c.id, c.course_code, c.course_name
    FROM courses c
    JOIN course_instructors ci ON ci.course_id = c.id
    WHERE ci.instructor_id = ?
");
mysqli_stmt_bind_param($stmt, 'i', $instructor_id);
mysqli_stmt_execute($stmt);
$courses = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
mysqli_stmt_close($stmt);

/* =========================
   VALIDATION HELPERS
========================= */
function v_int($v, $min, $max) {
    if (!filter_var($v, FILTER_VALIDATE_INT)) return false;
    return ($v >= $min && $v <= $max) ? (int)$v : false;
}
function v_float($v, $min, $max) {
    if (!is_numeric($v)) return false;
    $v = (float)$v;
    return ($v >= $min && $v <= $max) ? $v : false;
}
function v_str($v, $max = 100) {
    $v = trim($v);
    return ($v !== '' && strlen($v) <= $max) ? $v : false;
}

/* =========================
   INSERT / UPDATE RESULT
========================= */
function saveResult($conn, $sid, $cid, $cont, $final, $sem, $year) {

    $stmt = mysqli_prepare($conn, "
        SELECT id FROM student_results
        WHERE student_id=? AND course_id=? AND semester=? AND year=?
    ");
    mysqli_stmt_bind_param($stmt, 'iisi', $sid, $cid, $sem, $year);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    $exists = mysqli_stmt_num_rows($stmt) > 0;
    mysqli_stmt_close($stmt);

    if ($exists) {
        $stmt = mysqli_prepare($conn, "
            UPDATE student_results
            SET continuous_mark=?, final_mark=?
            WHERE student_id=? AND course_id=? AND semester=? AND year=?
        ");
        mysqli_stmt_bind_param($stmt, 'ddiisi', $cont, $final, $sid, $cid, $sem, $year);
    } else {
        $stmt = mysqli_prepare($conn, "
            INSERT INTO student_results
            (student_id, course_id, continuous_mark, final_mark, semester, year)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        mysqli_stmt_bind_param($stmt, 'iiddsi', $sid, $cid, $cont, $final, $sem, $year);
    }
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

/* =========================
   GRADE CALCULATION
========================= */
function grade($c, $f) {
    $t = $c + $f;
    if ($t >= 90) return 'A+';
    if ($t >= 80) return 'A';
    if ($t >= 75) return 'B+';
    if ($t >= 70) return 'B';
    if ($t >= 60) return 'C';
    if ($t >= 50) return 'D';
    return 'F';
}

/* =========================
   FILTERS
========================= */
$course_id = v_int($_POST['course_id'] ?? 0, 1, 9999);
$semester  = v_str($_POST['semester'] ?? 'Main 1');
$year      = v_int($_POST['year'] ?? 2018, 2000, date('Y') + 5);

/* =========================
   FETCH STUDENTS
========================= */
$students = [];
if ($course_id) {
    $stmt = mysqli_prepare($conn, "
        SELECT s.id, s.student_number, s.fname
        FROM students s
        JOIN registrations r ON r.student_id=s.id
        WHERE r.course_id=? AND r.semester=? AND r.year=?
    ");
    mysqli_stmt_bind_param($stmt, 'isi', $course_id, $semester, $year);
    mysqli_stmt_execute($stmt);
    $students = mysqli_fetch_all(mysqli_stmt_get_result($stmt), MYSQLI_ASSOC);
    mysqli_stmt_close($stmt);
}

/* =========================
   MANUAL ENTRY
========================= */
if (isset($_POST['manual'])) {
    $sid = v_int($_POST['student_id'], 1, 99999);
    $c = v_float($_POST['continuous_mark'], 0, 50);
    $f = v_float($_POST['final_mark'], 0, 50);

    if ($sid && $course_id && $c !== false && $f !== false) {
        saveResult($conn, $sid, $course_id, $c, $f, $semester, $year);
        $g = grade($c, $f);

        $u = mysqli_prepare($conn,"
            UPDATE student_results
            SET status=?
            WHERE student_id=? AND course_id=? AND semester=? AND year=?
        ");
        mysqli_stmt_bind_param($u,'siisi',$g,$sid,$course_id,$semester,$year);
        mysqli_stmt_execute($u);
        mysqli_stmt_close($u);

        echo "<div style='color:green'>Result saved</div>";
    } else {
        echo "<div style='color:red'>Invalid input</div>";
    }
}
?>

<h2>Enter Results</h2>

<form method="POST">
    <label>Course</label><br>
    <select name="course_id" required onchange="this.form.submit()">
        <option value="">--Select--</option>
        <?php foreach($courses as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $course_id==$c['id']?'selected':'' ?>>
                <?= htmlspecialchars($c['course_code'] . ' - ' . $c['course_name']) ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Semester</label><br>
    <select name="semester">
        <?php
        $semesters = ['Main 1', 'Main 2', 'Summer'];
        foreach ($semesters as $s): ?>
            <option value="<?= htmlspecialchars($s) ?>" <?= $semester == $s ? 'selected' : '' ?>><?= htmlspecialchars($s) ?></option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Year</label><br>
    <select name="year">
        <?php for ($y = 2000; $y <= date('Y') + 5; $y++): ?>
            <option value="<?= $y ?>" <?= $year == $y ? 'selected' : '' ?>><?= $y ?></option>
        <?php endfor; ?>
    </select><br><br>
</form>

<?php if ($course_id): ?>
<form method="POST">
    <input type="hidden" name="course_id" value="<?= $course_id ?>">
    <input type="hidden" name="semester" value="<?= htmlspecialchars($semester) ?>">
    <input type="hidden" name="year" value="<?= $year ?>">

    <label>Student</label><br>
    <select name="student_id" required>
        <option value="">--Select Student--</option>
        <?php foreach($students as $s): ?>
            <option value="<?= $s['id'] ?>">
                <?= htmlspecialchars($s['fname'].' ('.$s['student_number'].')') ?>
            </option>
        <?php endforeach; ?>
    </select><br><br>

    <label>Continuous (50)</label><br>
    <input type="number" name="continuous_mark" max="50" step="0.01" required><br><br>

    <label>Final (50)</label><br>
    <input type="number" name="final_mark" max="50" step="0.01" required><br><br>

    <button name="manual">Save</button>
</form>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>

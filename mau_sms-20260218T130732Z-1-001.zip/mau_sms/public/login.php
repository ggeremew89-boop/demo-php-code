<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $username_q = mysqli_real_escape_string($conn, $username);
    $res = mysqli_query($conn, "SELECT * FROM users WHERE username='$username_q' LIMIT 1");

    if ($res && mysqli_num_rows($res) === 1) {
        $user = mysqli_fetch_assoc($res);
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            // keep legacy role string
            $_SESSION['role'] = $user['role'];
            // expose roles as array
            $_SESSION['roles'] = array_map('trim', explode(',', $user['role']));

            // Enrich roles from domain tables when users.role is not authoritative
            $uid = (int)$user['id'];
            $res = mysqli_query($conn, "SELECT id FROM department_heads WHERE user_id=$uid LIMIT 1");
            if ($res && mysqli_num_rows($res) > 0 && !in_array('department_head', $_SESSION['roles'])) {
                $_SESSION['roles'][] = 'department_head';
            }
            $res = mysqli_query($conn, "SELECT id FROM instructors WHERE user_id=$uid LIMIT 1");
            if ($res && mysqli_num_rows($res) > 0 && !in_array('instructor', $_SESSION['roles'])) {
                $_SESSION['roles'][] = 'instructor';
            }
            $res = mysqli_query($conn, "SELECT id FROM students WHERE user_id=$uid LIMIT 1");
            if ($res && mysqli_num_rows($res) > 0 && !in_array('student', $_SESSION['roles'])) {
                $_SESSION['roles'][] = 'student';
            }

            // set active role if not already set
            if (empty($_SESSION['active_role'])) {
                $_SESSION['active_role'] = $_SESSION['roles'][0] ?? null;
            }

            // Redirect based on active role
            $primary = $_SESSION['active_role'];
            if ($primary === 'student') {
                header("Location: dashboard_student.php");
            } elseif ($primary === 'instructor') {
                header("Location: dashboard_instructor.php");
            } elseif ($primary === 'department_head') {
                header("Location: dashboard_department_head.php");
            } elseif ($primary === 'registrar') {
                header("Location: dashboard_registrar.php");
            } elseif (in_array($primary, ['admin','superadmin'])) {
                header("Location: dashboard_admin.php");
            } else {
                header("Location: home.php");
            }
            exit;
        } else {
            $error = "Invalid username or password.";
        }
    } else {
        $error = "User not found.";
    }
}

include __DIR__ . '/../includes/header.php';
?>



<div class="login-box">
    <img src="../assets/image/bb.jfif" alt="mm">
    <h2>Login to MAU SMS</h2>
    <?php if (isset($error)) : ?>
        <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    <form method="POST" action="" >
        <input name="username" placeholder="Username" required autofocus>
        <input name="password" type="password" placeholder="Password" required>
        <button type="submit" name="login">Login</button>
    </form>
    <a href="forgot_password.php">Forgot Password?</a>

<link rel="stylesheet" href="../assets/css/style.css">
<?php include __DIR__ . '/../includes/footer.php'; ?>

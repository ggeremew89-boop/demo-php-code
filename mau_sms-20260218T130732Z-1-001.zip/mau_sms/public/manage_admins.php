<?php
// public/manage_admins.php

require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin']); // ONLY superadmin can access

require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$error = '';
$success = '';

// Safely get posted values or default to empty string
$posted_username = $_POST['username'] ?? '';
$posted_role = $_POST['role'] ?? '';

/* ==========================
   FETCH ADMIN USERS
========================== */
$admins = mysqli_query($conn, "
    SELECT id, username, role, created_at
    FROM users
    WHERE role IN ('admin','registrar')
    ORDER BY id DESC
");

/* ==========================
   FORM SUBMISSION
========================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_admin'])) {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $new_role = $_POST['role'] ?? '';

    $allowed_roles = ['admin', 'registrar'];

    if ($username === '' || $password === '' || !in_array($new_role, $allowed_roles)) {
        $error = "All fields are required and role must be admin or registrar.";
    } else {
        // Check if user exists
        $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE username = ?");
        if (!$stmt) {
            $error = "Database error: " . mysqli_error($conn);
        } else {
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $user_id);

            if (!mysqli_stmt_fetch($stmt)) {
                $error = "User does not exist. Please register user first.";
            }
            mysqli_stmt_close($stmt);
        }

        if (!$error) {
            $hash = password_hash($password, PASSWORD_DEFAULT);

            // Update user role and password
            $stmt = mysqli_prepare($conn, "UPDATE users SET role=?, password=? WHERE id=?");
            if (!$stmt) {
                $error = "Database error: " . mysqli_error($conn);
            } else {
                mysqli_stmt_bind_param($stmt, "ssi", $new_role, $hash, $user_id);
                if (!mysqli_stmt_execute($stmt)) {
                    $error = "Failed to update user: " . mysqli_stmt_error($stmt);
                }
                mysqli_stmt_close($stmt);
            }
        }

        if (!$error) {
            $user_id_safe = (int)$user_id;

            // Remove user from all admin-related role tables
            mysqli_query($conn, "DELETE FROM admins WHERE user_id=$user_id_safe");
            mysqli_query($conn, "DELETE FROM registrars WHERE user_id=$user_id_safe");

            // Insert into the correct role table
            if ($new_role === 'admin') {
                $res = mysqli_query($conn, "INSERT INTO admins (user_id) VALUES ($user_id_safe)");
                if ($res) {
                    $success = "User assigned as ADMIN successfully.";
                } else {
                    $error = "Failed to assign admin role: " . mysqli_error($conn);
                }
            } elseif ($new_role === 'registrar') {
                $res = mysqli_query($conn, "INSERT INTO registrars (user_id) VALUES ($user_id_safe)");
                if ($res) {
                    $success = "User assigned as REGISTRAR successfully.";
                } else {
                    $error = "Failed to assign registrar role: " . mysqli_error($conn);
                }
            }
        }
    }
}
?>

<h2>Manage Admins and Registrars</h2>

<?php if ($error): ?>
    <div style="color:red;margin-bottom:10px;"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div style="color:green;margin-bottom:10px;"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="POST">

<label>Role</label><br>
<select name="role" required>
    <option value="admin" <?= $posted_role === 'admin' ? 'selected' : '' ?>>Admin</option>
    <option value="registrar" <?= $posted_role === 'registrar' ? 'selected' : '' ?>>Registrar</option>
</select><br><br>

<label>Username</label><br>
<input type="text" name="username" value="<?= htmlspecialchars($posted_username) ?>" required><br><br>

<label>Password</label><br>
<input type="password" name="password" required><br><br>

<button type="submit" name="add_admin">Save Changes</button>

</form>

<hr>

<h3>Existing Admin and Registrar Users</h3>
<table border="1" width="100%">
<tr>
    <th>ID</th>
    <th>Username</th>
    <th>Role</th>
    <th>Created</th>
</tr>

<?php while ($row = mysqli_fetch_assoc($admins)): ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= htmlspecialchars($row['username']) ?></td>
    <td><?= htmlspecialchars($row['role']) ?></td>
    <td><?= $row['created_at'] ?></td>
</tr>
<?php endwhile; ?>
</table>

<?php include __DIR__ . '/../includes/footer.php'; ?>

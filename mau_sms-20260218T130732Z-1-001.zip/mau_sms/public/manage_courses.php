<?php
session_start();

require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

$user_id = $_SESSION['user_id'] ?? 0;

if (!$user_id) {
    die('User not logged in.');
}

// Fetch department of the department head
$query = "SELECT department FROM department_heads WHERE user_id = ?";
$stmt = mysqli_prepare($conn, $query);
if (!$stmt) {
    die("Prepare failed: " . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if (!$result) {
    die("Getting result failed: " . mysqli_error($conn));
}

$dept_head = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

$department = $dept_head['department'] ?? null;
if (!$department) {
    die("No department found for this department head.");
}

// Fetch courses for the department
$query = "SELECT * FROM courses WHERE department = ?";
$stmt = mysqli_prepare($conn, $query);
if (!$stmt) {
    die("Prepare failed: " . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, 's', $department);
mysqli_stmt_execute($stmt);
$courses_result = mysqli_stmt_get_result($stmt);
if (!$courses_result) {
    die("Getting courses failed: " . mysqli_error($conn));
}
?>

<h2>Manage Courses (Department: <?= htmlspecialchars($department) ?>)</h2>

<table border="1" cellpadding="5" cellspacing="0" style="width:100%; margin-top:10px;">
    <thead>
        <tr>
            <th>ID</th>
            <th>Course Code</th>
            <th>Course Name</th>
            <th>Credit Hour</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($course = mysqli_fetch_assoc($courses_result)): ?>
            <tr>
                <td><?= $course['id'] ?></td>
                <td><?= htmlspecialchars($course['course_code']) ?></td>
                <td><?= htmlspecialchars($course['course_name']) ?></td>
                <td><?= htmlspecialchars($course['credit_hour']) ?></td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php
// my_registrations.php
require_once __DIR__ . '/../includes/auth.php';
require_role(['student']);
include __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$user_id = intval($_SESSION['user_id']);

// Fetch the student record linked to the logged-in user
$student_res = mysqli_query($conn, "SELECT * FROM students WHERE user_id = $user_id LIMIT 1");
if (!$student_res) {
    die("<div class='error'>Database error: " . mysqli_error($conn) . "</div>");
}
$student = mysqli_fetch_assoc($student_res);
if (!$student) {
    die("<div class='error'>Student record not found.</div>");
}

$student_id = intval($student['id']);

// Fetch registrations for this student with course details
$regs = mysqli_query($conn, "SELECT r.*, c.course_code, c.course_name 
                             FROM registrations r 
                             LEFT JOIN courses c ON r.course_id = c.id 
                             WHERE r.student_id = $student_id 
                             ORDER BY r.created_at DESC");
if (!$regs) {
    die("<div class='error'>Query error: " . mysqli_error($conn) . "</div>");
}
?>

<h2>My Registrations</h2>

<table class="table" border="1" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th>Course</th>
            <th>Semester</th>
            <th>Year</th>
            <th>Status</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($r = mysqli_fetch_assoc($regs)): ?>
        <tr>
            <td><?php echo htmlspecialchars($r['course_code'] . ' - ' . $r['course_name']); ?></td>
            <td><?php echo htmlspecialchars($r['semester']); ?></td>
            <td><?php echo htmlspecialchars($r['year']); ?></td>
            <td><?php echo htmlspecialchars($r['status']); ?></td>
            <td><?php echo htmlspecialchars($r['created_at']); ?></td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php
include __DIR__ . '/../includes/footer.php';

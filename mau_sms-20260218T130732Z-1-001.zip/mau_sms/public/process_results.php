<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['instructor']);
include __DIR__ . '/../includes/db.php';

function insertOrUpdateResult($conn, $student_id, $course_id, $continuous_mark, $final_mark, $semester, $year) {
    // Check if result already exists
    $stmt = mysqli_prepare($conn, "SELECT id FROM results WHERE student_id=? AND course_id=? AND semester=? AND year=?");
    if (!$stmt) die("Prepare failed: " . mysqli_error($conn));

    mysqli_stmt_bind_param($stmt, 'iiss', $student_id, $course_id, $semester, $year);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) > 0) {
        // Update existing result
        $stmt_update = mysqli_prepare($conn, "UPDATE results SET continuous_mark=?, final_mark=? WHERE student_id=? AND course_id=? AND semester=? AND year=?");
        if (!$stmt_update) die("Prepare failed: " . mysqli_error($conn));
        mysqli_stmt_bind_param($stmt_update, 'ddiisss', $continuous_mark, $final_mark, $student_id, $course_id, $semester, $year);
        mysqli_stmt_execute($stmt_update);
        mysqli_stmt_close($stmt_update);
    } else {
        // Insert new result
        $stmt_insert = mysqli_prepare($conn, "INSERT INTO results (student_id, course_id, continuous_mark, final_mark, semester, year) VALUES (?, ?, ?, ?, ?, ?)");
        if (!$stmt_insert) die("Prepare failed: " . mysqli_error($conn));
        mysqli_stmt_bind_param($stmt_insert, 'iiddss', $student_id, $course_id, $continuous_mark, $final_mark, $semester, $year);
        mysqli_stmt_execute($stmt_insert);
        mysqli_stmt_close($stmt_insert);
    }
    mysqli_stmt_close($stmt);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ----------- MANUAL ENTRY -----------
    if (isset($_POST['manual'])) {
        $student_id = intval($_POST['student_id']);
        $course_id = intval($_POST['course_id']);
        $continuous_mark = floatval($_POST['continuous_mark']);
        $final_mark = floatval($_POST['final_mark']);
        $semester = trim($_POST['semester']);
        $year = trim($_POST['year']);

        insertOrUpdateResult($conn, $student_id, $course_id, $continuous_mark, $final_mark, $semester, $year);

        header("Location: upload_results.php?msg=Result saved successfully");
        exit;
    }

    // ----------- CSV UPLOAD -----------
    if (isset($_POST['upload_csv']) && isset($_FILES['csv_file'])) {
        $course_id = intval($_POST['course_id']);
        $file = $_FILES['csv_file']['tmp_name'];

        if (($handle = fopen($file, "r")) !== false) {
            $header = fgetcsv($handle); // skip header if any

            while (($data = fgetcsv($handle, 1000, ",")) !== false) {
                // CSV format: student_number,continuous_mark,final_mark,semester,year
                $student_number = trim($data[0]);
                $continuous_mark = floatval($data[1]);
                $final_mark = floatval($data[2]);
                $semester = trim($data[3]);
                $year = trim($data[4]);

                // Get student_id from student_number
                $stmt = mysqli_prepare($conn, "SELECT id FROM students WHERE student_number=?");
                mysqli_stmt_bind_param($stmt, 's', $student_number);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_bind_result($stmt, $student_id);
                if (mysqli_stmt_fetch($stmt)) {
                    insertOrUpdateResult($conn, $student_id, $course_id, $continuous_mark, $final_mark, $semester, $year);
                }
                mysqli_stmt_close($stmt);
            }
            fclose($handle);
        }
        header("Location: upload_results.php?msg=CSV processed successfully");
        exit;
    }
}

?>

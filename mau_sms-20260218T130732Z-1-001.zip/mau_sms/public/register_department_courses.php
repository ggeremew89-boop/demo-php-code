<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['registrar','department_head','admin','superadmin']);
include __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

function e($s){ return htmlspecialchars($s); }

$departments = [];
$dres = mysqli_query($conn, "SELECT department_name FROM departments ORDER BY department_name");
while ($d = mysqli_fetch_assoc($dres)) $departments[] = $d['department_name'];

$current_user_department = null;
$uid = $_SESSION['user_id'] ?? 0;
if (function_exists('has_role') && has_role('department_head')) {
    $dq = mysqli_prepare($conn, "SELECT department FROM department_heads WHERE user_id=? LIMIT 1");
    mysqli_stmt_bind_param($dq, 'i', $uid);
    mysqli_stmt_execute($dq);
    $dr = mysqli_stmt_get_result($dq);
    $drow = mysqli_fetch_assoc($dr);
    mysqli_stmt_close($dq);
    $current_user_department = $drow['department'] ?? null;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['do_register'])) {
    $department = $_POST['department'] ?? '';
    $semester = trim($_POST['semester'] ?? '');
    $year = trim($_POST['year'] ?? '');

    if ($current_user_department && $department !== $current_user_department) {
        $message = 'As Department Head you can only register students in your own department.';
    } elseif (!$department || !$semester || !$year) {
        $message = 'Please provide department, semester and year.';
    } else {
        // fetch courses
        $courses = [];
        $cstmt = mysqli_prepare($conn, "SELECT id FROM courses WHERE department=?");
        mysqli_stmt_bind_param($cstmt, 's', $department);
        mysqli_stmt_execute($cstmt);
        $cres = mysqli_stmt_get_result($cstmt);
        while ($crow = mysqli_fetch_assoc($cres)) $courses[] = (int)$crow['id'];
        mysqli_stmt_close($cstmt);

        // fetch students
        $students = [];
        $sstmt = mysqli_prepare($conn, "SELECT id FROM students WHERE department=?");
        mysqli_stmt_bind_param($sstmt, 's', $department);
        mysqli_stmt_execute($sstmt);
        $sres = mysqli_stmt_get_result($sstmt);
        while ($srow = mysqli_fetch_assoc($sres)) $students[] = (int)$srow['id'];
        mysqli_stmt_close($sstmt);

        if (empty($courses) || empty($students)) {
            $message = 'No courses or students found for that department.';
        } else {
            $count = 0;
            // prepare insert with check to avoid duplicates
            $ins = mysqli_prepare($conn, "INSERT INTO registrations (student_id, course_id, semester, year, status) VALUES (?,?,?,?, 'registered')");
            foreach ($courses as $cid) {
                foreach ($students as $sid) {
                    // check exists
                    $chk = mysqli_prepare($conn, "SELECT id FROM registrations WHERE student_id=? AND course_id=? AND semester=? AND year=? LIMIT 1");
                    mysqli_stmt_bind_param($chk, 'iiss', $sid, $cid, $semester, $year);
                    mysqli_stmt_execute($chk);
                    mysqli_stmt_store_result($chk);
                    $exists = mysqli_stmt_num_rows($chk) > 0;
                    mysqli_stmt_close($chk);
                    if (!$exists) {
                        mysqli_stmt_bind_param($ins, 'iiss', $sid, $cid, $semester, $year);
                        if (mysqli_stmt_execute($ins)) $count++;
                    }
                }
            }
            mysqli_stmt_close($ins);
            $message = "$count registrations created.";
        }
    }
}

?>

<h2>Bulk register department students into department courses</h2>
<?php if($message): ?><div style="color:green"><?= e($message) ?></div><?php endif; ?>

<form method="POST">
    <label>Department</label><br>
    <?php if ($current_user_department): ?>
        <input type="hidden" name="department" value="<?= e($current_user_department) ?>">
        <input value="<?= e($current_user_department) ?>" disabled><br><br>
    <?php else: ?>
        <select name="department" required>
            <option value="">-- Select Department --</option>
            <?php foreach($departments as $d): ?>
                <option value="<?= e($d) ?>"><?= e($d) ?></option>
            <?php endforeach; ?>
        </select><br><br>
    <?php endif; ?>

    <label>Semester</label><br>
    <input name="semester" placeholder="e.g. 2025-1" required><br><br>

    <label>Year</label><br>
    <input name="year" placeholder="e.g. 2025" required><br><br>

    <button type="submit" name="do_register">Register All</button>
</form>

<?php include __DIR__ . '/../includes/footer.php'; ?>

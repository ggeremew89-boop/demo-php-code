<?php
// public/manage_students.php

require_once __DIR__ . '/../includes/auth.php';
require_role(['registrar']); // Only registrar can access

require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$error = '';
$success = '';

// Fetch departments for the dropdown
$departments = [];
$dep_res = mysqli_query($conn, "SELECT department_code, department_name FROM departments ORDER BY department_name");
while ($dep = mysqli_fetch_assoc($dep_res)) {
    $departments[] = $dep;
}

// Handle add student POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_student'])) {
    // Collect form inputs safely
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    $student_number = trim($_POST['student_number'] ?? '');
    $fname = trim($_POST['fname'] ?? '');
    $lname = trim($_POST['lname'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $department = $_POST['department'] ?? '';
    $year_level = trim($_POST['year_level'] ?? '');
    $email = trim($_POST['email'] ?? '') ?: null;
    $phone = trim($_POST['phone'] ?? '') ?: null;

    // Validate required fields
    if (!$username || !$password || !$confirm || !$student_number || !$fname || !$lname || !$department) {
        $error = "Please fill in all required fields.";
    } elseif ($password !== $confirm) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) <= 6) {
        $error = "Password must be more than 6 characters.";
    } else {
        // Check if username already exists
        $chk = mysqli_prepare($conn, "SELECT id FROM users WHERE username=?");
        mysqli_stmt_bind_param($chk, 's', $username);
        mysqli_stmt_execute($chk);
        mysqli_stmt_store_result($chk);

        if (mysqli_stmt_num_rows($chk) > 0) {
            $error = "Username already exists.";
        }
        mysqli_stmt_close($chk);
    }

    // Insert new user and student if no errors
    if (!$error) {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $ins = mysqli_prepare($conn, "INSERT INTO users (username, password, role) VALUES (?, ?, 'student')");
        mysqli_stmt_bind_param($ins, 'ss', $username, $hash);

        if (mysqli_stmt_execute($ins)) {
            $user_id = mysqli_insert_id($conn);
            mysqli_stmt_close($ins);

            $ins2 = mysqli_prepare($conn, "INSERT INTO students (user_id, student_number, fname, lname, gender, department, year_level, email, phone, registration_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Not Registered')");
            mysqli_stmt_bind_param($ins2, 'issssssss', $user_id, $student_number, $fname, $lname, $gender, $department, $year_level, $email, $phone);

            if (mysqli_stmt_execute($ins2)) {
                $success = "Student added successfully.";
            } else {
                $error = "Error adding student details: " . mysqli_stmt_error($ins2);
            }
            mysqli_stmt_close($ins2);
        } else {
            $error = "Error adding user: " . mysqli_stmt_error($ins);
        }
    }
}

// Handle AJAX request to update registration status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && isset($_POST['student_id'])) {
    $student_id = (int)$_POST['student_id'];
    $action = $_POST['action'];

    $allowed_status = ['registered', 'cleaned', 'not registered'];

    if (in_array($action, $allowed_status)) {
        $upd = mysqli_prepare($conn, "UPDATE students SET registration_status = ? WHERE id = ?");
        mysqli_stmt_bind_param($upd, 'si', $action, $student_id);
        if (mysqli_stmt_execute($upd)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to update status.']);
        }
        mysqli_stmt_close($upd);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid status']);
    }
    exit;
}

// Fetch all students
$students_res = mysqli_query($conn, "
    SELECT s.*, u.username, d.department_name
    FROM students s
    JOIN users u ON s.user_id = u.id
    LEFT JOIN departments d ON s.department = d.department_code
    ORDER BY s.id DESC
");
?>

<h2>Manage Students</h2>

<?php if ($error): ?>
    <div style="color:red"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div style="color:green"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>


<!-- List all students -->
<h3>Students List</h3>
<table border="1" cellpadding="8" cellspacing="0" style="width:100%; border-collapse: collapse;">
    <thead>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Student Number</th>
            <th>Name</th>
            <th>Gender</th>
            <th>Department</th>
            <th>Year Level</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Registration Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($s = mysqli_fetch_assoc($students_res)): ?>
            <tr id="student-<?= $s['id'] ?>">
                <td><?= $s['id'] ?></td>
                <td><?= htmlspecialchars($s['username']) ?></td>
                <td><?= htmlspecialchars($s['student_number']) ?></td>
                <td><?= htmlspecialchars($s['fname'] . ' ' . $s['lname']) ?></td>
                <td><?= htmlspecialchars($s['gender']) ?></td>
                <td><?= htmlspecialchars($s['department_name'] ?? $s['department']) ?></td>
                <td><?= htmlspecialchars($s['year_level']) ?></td>
                <td><?= htmlspecialchars($s['email']) ?></td>
                <td><?= htmlspecialchars($s['phone']) ?></td>
                <td class="reg-status"><?= htmlspecialchars(ucfirst($s['registration_status'])) ?></td>
                <td>
                    <?php if (strtolower($s['registration_status']) !== 'registered'): ?>
                        <button class="updateStatusBtn" data-id="<?= $s['id'] ?>" data-action="registered">✅ Register</button>
                    <?php endif; ?>
                   <?php if (strtolower($s['registration_status']) !== 'cleaned'): ?>
                        <button class="updateStatusBtn" data-id="<?= $s['id'] ?>" data-action="cleaned">🧼 Clean</button>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<script>
document.querySelectorAll('.updateStatusBtn').forEach(button => {
    button.addEventListener('click', () => {
        const studentId = button.getAttribute('data-id');
        const action = button.getAttribute('data-action');

        fetch('', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `student_id=${encodeURIComponent(studentId)}&action=${encodeURIComponent(action)}`
        })
        .then(response => response.json())
        .then(data => {
            if(data.success) {
                // Update status text in the row
                const row = document.getElementById('student-' + studentId);
                if(row) {
                    row.querySelector('.reg-status').textContent = action.charAt(0).toUpperCase() + action.slice(1);
                    // Remove buttons and show only relevant one
                    const buttons = row.querySelectorAll('.updateStatusBtn');
                    buttons.forEach(btn => btn.style.display = 'inline-block');

                    if(action === 'registered') {
                        // Hide register button, show clean button
                        row.querySelector('[data-action="registered"]').style.display = 'none';
                        row.querySelector('[data-action="cleaned"]').style.display = 'inline-block';
                    } else if(action === 'cleaned') {
                        // Hide clean button, show register button
                        row.querySelector('[data-action="cleaned"]').style.display = 'none';
                        row.querySelector('[data-action="registered"]').style.display = 'inline-block';
                    }
                }
            } else {
                alert(data.error || 'Failed to update registration status');
            }
        })
        .catch(() => alert('Request failed'));
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>

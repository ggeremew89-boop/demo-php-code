<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['registrar']);
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$result = mysqli_query($conn, "SELECT s.*, u.username FROM students s JOIN users u ON s.user_id = u.id ORDER BY s.fname");
?>

<h2>Student Registrations</h2>
<table border="1" cellpadding="5" cellspacing="0">
<tr>
    <th>ID</th>
    <th>Username</th>
    <th>Student Number</th>
    <th>Name</th>
    <th>Gender</th>
    <th>Department</th>
    <th>Year Level</th>
    <th>Email</th>
    <th>Phone</th>
</tr>
<?php $i=1; while($row=mysqli_fetch_assoc($result)): ?>
<tr>
    <td><?= $i++ ?></td>
    <td><?= htmlspecialchars($row['username']) ?></td>
    <td><?= htmlspecialchars($row['student_number']) ?></td>
    <td><?= htmlspecialchars($row['fname'] . ' ' . $row['lname']) ?></td>
    <td><?= htmlspecialchars($row['gender']) ?></td>
    <td><?= htmlspecialchars($row['department']) ?></td>
    <td><?= htmlspecialchars($row['year_level']) ?></td>
    <td><?= htmlspecialchars($row['email']) ?></td>
    <td><?= htmlspecialchars($row['phone']) ?></td>
</tr>
<?php endwhile; ?>
</table>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php
// department_reports.php

session_start();

require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/header.php';

// Get logged-in user ID
$user_id = $_SESSION['user_id'] ?? 0;
$hod_dept = null;

if ($user_id > 0) {
    $stmt = mysqli_prepare($conn, "SELECT department FROM department_heads WHERE user_id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $dept);
    if (mysqli_stmt_fetch($stmt)) {
        $hod_dept = $dept;
    }
    mysqli_stmt_close($stmt);
}

if (!$hod_dept) {
    die("<div style='color:red; font-weight:bold; padding:10px;'>Your department information not found. Cannot display reports.</div>");
}

// Escape department for safe SQL usage
$dept_safe = mysqli_real_escape_string($conn, $hod_dept);

// Queries
$students_by_year_q = "SELECT year_level, COUNT(*) as cnt FROM students WHERE department = '$dept_safe' GROUP BY year_level ORDER BY year_level";
$students_by_year_res = mysqli_query($conn, $students_by_year_q);

$courses_q = "SELECT course_code, course_name FROM courses WHERE department = '$dept_safe' ORDER BY course_code";
$courses_res = mysqli_query($conn, $courses_q);

$instructors_q = "SELECT instructor_code, fname, lname FROM instructors WHERE department = '$dept_safe' ORDER BY fname, lname";
$instructors_res = mysqli_query($conn, $instructors_q);
?>

<div class="container" style="max-width:900px; margin:auto; padding:20px;">
    <h2>Department Reports - <?= htmlspecialchars($hod_dept) ?></h2>

    <h3>Students by Year Level</h3>
    <table border="1" cellpadding="6" cellspacing="0" width="50%" style="border-collapse:collapse;">
        <thead style="background:#003366; color:white;">
            <tr><th>Year Level</th><th>Count</th></tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($students_by_year_res) === 0): ?>
                <tr><td colspan="2" style="text-align:center;">No data found.</td></tr>
            <?php else: ?>
                <?php while ($r = mysqli_fetch_assoc($students_by_year_res)): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['year_level']) ?></td>
                        <td><?= intval($r['cnt']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <h3>Courses</h3>
    <table border="1" cellpadding="6" cellspacing="0" width="70%" style="border-collapse:collapse;">
        <thead style="background:#003366; color:white;">
            <tr><th>Course Code</th><th>Course Name</th></tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($courses_res) === 0): ?>
                <tr><td colspan="2" style="text-align:center;">No courses found.</td></tr>
            <?php else: ?>
                <?php while ($c = mysqli_fetch_assoc($courses_res)): ?>
                    <tr>
                        <td><?= htmlspecialchars($c['course_code']) ?></td>
                        <td><?= htmlspecialchars($c['course_name']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <h3>Instructors</h3>
    <table border="1" cellpadding="6" cellspacing="0" width="70%" style="border-collapse:collapse;">
        <thead style="background:#003366; color:white;">
            <tr><th>Instructor Code</th><th>Name</th></tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($instructors_res) === 0): ?>
                <tr><td colspan="2" style="text-align:center;">No instructors found.</td></tr>
            <?php else: ?>
                <?php while ($i = mysqli_fetch_assoc($instructors_res)): ?>
                    <tr>
                        <td><?= htmlspecialchars($i['instructor_code']) ?></td>
                        <td><?= htmlspecialchars($i['fname'] . ' ' . $i['lname']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

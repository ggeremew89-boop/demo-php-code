<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['registrar','admin','superadmin']);
include __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';
// Totals
$totals = ['students'=>0,'registrations'=>0,'courses'=>0,'departments'=>0];
$r = mysqli_query($conn, "SELECT COUNT(*) AS c FROM students"); if ($r) $totals['students'] = (int)mysqli_fetch_assoc($r)['c'];
// prefer student_registration (registrations table may be absent)
$r = mysqli_query($conn, "SELECT COUNT(*) AS c FROM student_registration"); if ($r) $totals['registrations'] = (int)mysqli_fetch_assoc($r)['c'];
$r = mysqli_query($conn, "SELECT COUNT(*) AS c FROM courses"); if ($r) $totals['courses'] = (int)mysqli_fetch_assoc($r)['c'];
$r = mysqli_query($conn, "SELECT COUNT(*) AS c FROM departments"); if ($r) $totals['departments'] = (int)mysqli_fetch_assoc($r)['c'];

// Students by department
$by_dept = [];
$q = "SELECT d.department_name, COUNT(s.id) AS students
      FROM departments d
      LEFT JOIN students s ON s.department = d.department_name
      GROUP BY d.department_name
      ORDER BY d.department_name";
$res = mysqli_query($conn, $q);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) $by_dept[] = $row;
}

// Courses by department
$courses_by_dept = [];
$qc = "SELECT department, COUNT(*) AS courses FROM courses GROUP BY department ORDER BY department";
$resc = mysqli_query($conn, $qc);
if ($resc) {
    while ($crow = mysqli_fetch_assoc($resc)) $courses_by_dept[] = $crow;
}

// If current user is a department_head, fetch their department to highlight
$current_user_department = null;
$current_user_id = $_SESSION['user_id'] ?? 0;
if (function_exists('has_role') && has_role('department_head')) {
    $dq = mysqli_prepare($conn, "SELECT department FROM department_heads WHERE user_id=? LIMIT 1");
    if ($dq) {
        mysqli_stmt_bind_param($dq, 'i', $current_user_id);
        mysqli_stmt_execute($dq);
        $dr = mysqli_stmt_get_result($dq);
        $drow = mysqli_fetch_assoc($dr);
        mysqli_stmt_close($dq);
        $current_user_department = $drow['department'] ?? null;
    }
}

// Recent student registrations (last 20)
$recent_regs = [];
$q2 = "SELECT sr.id, sr.created_at, sr.semester, sr.status, s.student_number, s.fname AS student_fname, s.lname AS student_lname
       FROM student_registration sr
       JOIN students s ON sr.student_id = s.id
       ORDER BY sr.created_at DESC LIMIT 20";
$res2 = mysqli_query($conn, $q2);
if ($res2) {
    while ($row = mysqli_fetch_assoc($res2)) $recent_regs[] = $row;
}

?>

<h1>Registrar Reports</h1>

<h3>Summary</h3>
<ul>
    <li><strong>Total students:</strong> <?= $totals['students'] ?></li>
    <li><strong>Total departments:</strong> <?= $totals['departments'] ?></li>
    <li><strong>Total student registrations:</strong> <?= $totals['registrations'] ?></li>
    <li><strong>Total courses:</strong> <?= $totals['courses'] ?></li>
</ul>

<h3>Students by Department</h3>
<table border="1" width="100%">
<tr><th>Department</th><th>Students</th></tr>
<?php foreach($by_dept as $d): ?>
    <tr>
        <td><?= htmlspecialchars($d['department_name']) ?></td>
        <td><?= (int)$d['students'] ?></td>
    </tr>
<?php endforeach; ?>
</table>

<h3>Courses by Department</h3>
<table border="1" width="100%">
<tr><th>Department</th><th>Courses</th></tr>
<?php foreach($courses_by_dept as $c): ?>
    <tr>
        <td><?= htmlspecialchars($c['department']) ?><?php if($current_user_department && $c['department']===$current_user_department) echo ' (your dept)'; ?></td>
        <td><?= (int)$c['courses'] ?></td>
    </tr>
<?php endforeach; ?>
</table>

<?php if ($current_user_department): ?>
    <p><strong>Your department (<?= htmlspecialchars($current_user_department) ?>) total courses:</strong>
    <?php
        $dept_total = 0;
        foreach($courses_by_dept as $c) if ($c['department']===$current_user_department) $dept_total = (int)$c['courses'];
        echo $dept_total;
    ?>
    </p>
<?php endif; ?>

<h3>Recent Student Registrations (latest 20)</h3>
<table border="1" width="100%">
<tr><th>ID</th><th>Date</th><th>Student</th><th>Student No.</th><th>Semester</th><th>Status</th></tr>
<?php foreach($recent_regs as $rr): ?>
    <tr>
        <td><?= (int)$rr['id'] ?></td>
        <td><?= htmlspecialchars($rr['created_at']) ?></td>
        <td><?= htmlspecialchars($rr['student_fname'].' '.$rr['student_lname']) ?></td>
        <td><?= htmlspecialchars($rr['student_number']) ?></td>
        <td><?= htmlspecialchars($rr['semester']) ?></td>
        <td><?= htmlspecialchars($rr['status'] ?? '') ?></td>
    </tr>
<?php endforeach; ?>
</table>


<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin','admin']);
require_once __DIR__ . '/../includes/db.php';

$id = $_GET['id'] ?? null;
if (!$id) die("ID missing.");

$stmt = mysqli_prepare($conn, "DELETE FROM students WHERE id=?");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

header("Location: view_students.php");
exit;

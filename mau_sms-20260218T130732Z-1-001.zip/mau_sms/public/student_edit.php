<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin','admin','register']);
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$id = $_GET['id'] ?? null;
if (!$id) die("Student ID missing.");

$stmt = mysqli_prepare($conn, "SELECT * FROM students WHERE id=?");
mysqli_stmt_bind_param($stmt, 'i', $id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$student = mysqli_fetch_assoc($res);
mysqli_stmt_close($stmt);

if (!$student) die("Student not found.");

$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $student_number = $_POST['student_number'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $gender = $_POST['gender'];
    $department = $_POST['department'];
    $year_level = $_POST['year_level'];
    $email = $_POST['email'];

    $upd = mysqli_prepare($conn,
        "UPDATE students SET
        student_number=?, fname=?, lname=?, gender=?,
        department=?, year_level=?, email=?
        WHERE id=?"
    );

    mysqli_stmt_bind_param($upd, 'sssssssi',
        $student_number, $fname, $lname, $gender,
        $department, $year_level, $email, $id
    );

    if (mysqli_stmt_execute($upd)) {
        $success = "Student updated successfully.";
    } else {
        $error = mysqli_stmt_error($upd);
    }
    mysqli_stmt_close($upd);
}
?>

<h2>Edit Student</h2>
<?php if($error): ?><div style="color:red"><?= $error ?></div><?php endif; ?>
<?php if($success): ?><div style="color:green"><?= $success ?></div><?php endif; ?>

<form method="POST">
Student Number<br><input name="student_number" value="<?= $student['student_number'] ?>"><br><br>
First Name<br><input name="fname" value="<?= $student['fname'] ?>"><br><br>
Last Name<br><input name="lname" value="<?= $student['lname'] ?>"><br><br>
Gender<br>
<select name="gender">
<option <?= $student['gender']=='Male'?'selected':'' ?>>Male</option>
<option <?= $student['gender']=='Female'?'selected':'' ?>>Female</option>
</select><br><br>
Department<br><input name="department" value="<?= $student['department'] ?>"><br><br>
Year Level<br><input name="year_level" value="<?= $student['year_level'] ?>"><br><br>
Email<br><input name="email" value="<?= $student['email'] ?>"><br><br>
<button type="submit">Update</button>
</form>

<?php include __DIR__ . '/../includes/footer.php'; ?>

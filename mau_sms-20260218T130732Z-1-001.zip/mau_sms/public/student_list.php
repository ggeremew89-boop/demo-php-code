<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_role(['superadmin','admin','registrar','department_head']);
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

// Handle status update
if (isset($_GET['action'], $_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'] === 'register' ? 'Registered' : 'Cleaned';

    $stmt = mysqli_prepare($conn, "UPDATE students SET registration_status=? WHERE id=?");
    mysqli_stmt_bind_param($stmt, 'si', $action, $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: student_list.php");
    exit;
}

// Fetch students (limit to department for department_head)
$user_role = $_SESSION['role'] ?? '';
$user_id = $_SESSION['user_id'] ?? 0;
$dept = null;
if ($user_role === 'department_head') {
    $stmt = mysqli_prepare($conn, "SELECT department FROM department_heads WHERE user_id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $dr = mysqli_stmt_get_result($stmt);
    mysqli_stmt_close($stmt);
    $rdr = mysqli_fetch_assoc($dr);
    $dept = $rdr['department'] ?? null;
}

if ($dept) {
    $stmt = mysqli_prepare($conn, "SELECT s.id, s.student_number, s.fname, s.lname, s.gender, s.department, s.email, s.registration_status FROM students s WHERE s.department = ? ORDER BY s.id DESC");
    mysqli_stmt_bind_param($stmt, 's', $dept);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    mysqli_stmt_close($stmt);
} else {
    $res = mysqli_query($conn, "SELECT s.id, s.student_number, s.fname, s.lname, s.gender, s.department, s.email, s.registration_status FROM students s ORDER BY s.id DESC");
}
?>

<h2>Student List</h2>
<table border="1" cellpadding="5" cellspacing="0">
    <thead>
        <tr>
            <th>ID</th>
            <th>Student Number</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Gender</th>
            <th>Department</th>
            <th>Email</th>
            <th>Registration Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php while($row = mysqli_fetch_assoc($res)): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['student_number']) ?></td>
            <td><?= htmlspecialchars($row['fname']) ?></td>
            <td><?= htmlspecialchars($row['lname']) ?></td>
            <td><?= htmlspecialchars($row['gender']) ?></td>
            <td><?= htmlspecialchars($row['department']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['registration_status']) ?></td>
            <td>
                <?php if($row['registration_status'] !== 'Registered'): ?>
                <a href="student_list.php?action=register&id=<?= $row['id'] ?>">✅ Register</a>
                <?php endif; ?>
                <?php if($row['registration_status'] !== 'Cleaned'): ?>
                <a href="student_list.php?action=clean&id=<?= $row['id'] ?>">🧹 Clean</a>
                <?php endif; ?>
                <?php if ($_SESSION['role']==='superadmin' || $_SESSION['role']==='admin' || ($_SESSION['role']==='department_head' && $row['department']===($dept ?? ''))): ?>
                    <a href="student_edit.php?id=<?= $row['id'] ?>">✏ Edit</a>
                    <a href="student_delete.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this student?')">🗑 Delete</a>
                <?php else: ?>
                    —
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php include __DIR__ . '/../includes/footer.php'; ?>

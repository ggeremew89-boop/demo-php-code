<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head']);
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

// Get logged-in user's department
$user_id = $_SESSION['user_id'];

$stmt = mysqli_prepare($conn, "SELECT department FROM department_heads WHERE user_id = ?");
if (!$stmt) {
    die("Prepare failed: " . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$dept_head = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$dept_head) {
    die("<div class='error'>Department Head record not found. Contact admin.</div>");
}

$department = $dept_head['department'];

// Handle Add Timetable Entry form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_timetable'])) {
    $course_id = intval($_POST['course_id']);
    $instructor_id = intval($_POST['instructor_id']);
    $day_of_week = $_POST['day_of_week'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $location = trim($_POST['location']);
    $semester = $_POST['semester'];
    $year = $_POST['year'];

    // Basic validation
    if ($course_id && $instructor_id && $day_of_week && $start_time && $end_time && $semester && $year) {
        // Ensure the course has an assigned instructor and matches selected instructor
        $chk = mysqli_prepare($conn, "SELECT instructor_id FROM course_instructors WHERE course_id = ? LIMIT 1");
        if (!$chk) {
            echo "<div class='error'>Prepare failed: " . mysqli_error($conn) . "</div>";
        } else {
            mysqli_stmt_bind_param($chk, 'i', $course_id);
            mysqli_stmt_execute($chk);
            $chk_res = mysqli_stmt_get_result($chk);
            $assigned = mysqli_fetch_assoc($chk_res);
            mysqli_stmt_close($chk);

            if (!$assigned) {
                echo "<div class='error'>Cannot add timetable: course is not assigned to any instructor. Assign an instructor first.</div>";
                // don't attempt insert
                $can_insert = false;
            } elseif (intval($assigned['instructor_id']) !== $instructor_id) {
                echo "<div class='error'>Selected instructor is not assigned to this course. Please pick the assigned instructor or reassign the course.</div>";
                $can_insert = false;
            } else {
                $can_insert = true;
            }
        }

        if (empty($can_insert)) {
            // skip insert
        } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO timetable (course_id, instructor_id, day_of_week, start_time, end_time, location, semester, year) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            echo "<div class='error'>Prepare failed: " . mysqli_error($conn) . "</div>";
        } else {
            mysqli_stmt_bind_param($stmt, "iissssss", $course_id, $instructor_id, $day_of_week, $start_time, $end_time, $location, $semester, $year);
            if (mysqli_stmt_execute($stmt)) {
                echo "<div class='success'>Timetable entry added successfully.</div>";
            } else {
                echo "<div class='error'>Error adding timetable entry: " . mysqli_stmt_error($stmt) . "</div>";
            }
            mysqli_stmt_close($stmt);
        }
        }
    } else {
        echo "<div class='error'>Please fill in all required fields.</div>";
    }
}

// Handle Delete Timetable Entry
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_timetable'])) {
    $del_id = intval($_POST['delete_id'] ?? 0);
    if ($del_id > 0) {
        // ensure this timetable entry belongs to a course in this department
        $chk = mysqli_prepare($conn, "SELECT t.id FROM timetable t JOIN courses c ON t.course_id = c.id WHERE t.id = ? AND c.department = ? LIMIT 1");
        if ($chk) {
            mysqli_stmt_bind_param($chk, 'is', $del_id, $department);
            mysqli_stmt_execute($chk);
            mysqli_stmt_store_result($chk);
            if (mysqli_stmt_num_rows($chk) > 0) {
                mysqli_stmt_close($chk);
                $del = mysqli_prepare($conn, "DELETE FROM timetable WHERE id = ?");
                mysqli_stmt_bind_param($del, 'i', $del_id);
                if (mysqli_stmt_execute($del)) {
                    echo "<div class='success'>Timetable entry deleted.</div>";
                } else {
                    echo "<div class='error'>Delete failed: " . mysqli_stmt_error($del) . "</div>";
                }
                mysqli_stmt_close($del);
            } else {
                mysqli_stmt_close($chk);
                echo "<div class='error'>Cannot delete: entry not found or not in your department.</div>";
            }
        } else {
            echo "<div class='error'>Prepare failed: " . mysqli_error($conn) . "</div>";
        }
    }
}

// Handle Update Timetable Entry
$editing = false;
$edit_row = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_timetable'])) {
    $update_id = intval($_POST['update_id'] ?? 0);
    $course_id = intval($_POST['course_id'] ?? 0);
    $instructor_id = intval($_POST['instructor_id'] ?? 0);
    $day_of_week = $_POST['day_of_week'] ?? '';
    $start_time = $_POST['start_time'] ?? '';
    $end_time = $_POST['end_time'] ?? '';
    $location = trim($_POST['location'] ?? '');
    $semester = $_POST['semester'] ?? '';
    $year = $_POST['year'] ?? '';

    if ($update_id && $course_id && $instructor_id && $day_of_week && $start_time && $end_time && $semester && $year) {
        // ensure course belongs to department
        $chk = mysqli_prepare($conn, "SELECT id FROM courses WHERE id = ? AND department = ? LIMIT 1");
        mysqli_stmt_bind_param($chk, 'is', $course_id, $department);
        mysqli_stmt_execute($chk);
        mysqli_stmt_store_result($chk);
        if (mysqli_stmt_num_rows($chk) === 0) {
            echo "<div class='error'>Course not found in your department.</div>";
            mysqli_stmt_close($chk);
        } else {
            mysqli_stmt_close($chk);
            // ensure assigned instructor matches
            $chk2 = mysqli_prepare($conn, "SELECT instructor_id FROM course_instructors WHERE course_id = ? LIMIT 1");
            mysqli_stmt_bind_param($chk2, 'i', $course_id);
            mysqli_stmt_execute($chk2);
            $res2 = mysqli_stmt_get_result($chk2);
            $assigned = mysqli_fetch_assoc($res2);
            mysqli_stmt_close($chk2);
            if (!$assigned) {
                echo "<div class='error'>Cannot update: course not assigned to any instructor.</div>";
            } elseif (intval($assigned['instructor_id']) !== $instructor_id) {
                echo "<div class='error'>Selected instructor is not assigned to this course.</div>";
            } else {
                $up = mysqli_prepare($conn, "UPDATE timetable SET course_id=?, instructor_id=?, day_of_week=?, start_time=?, end_time=?, location=?, semester=?, year=? WHERE id=?");
                mysqli_stmt_bind_param($up, 'iissssssi', $course_id, $instructor_id, $day_of_week, $start_time, $end_time, $location, $semester, $year, $update_id);
                if (mysqli_stmt_execute($up)) {
                    echo "<div class='success'>Timetable entry updated.</div>";
                } else {
                    echo "<div class='error'>Update failed: " . mysqli_stmt_error($up) . "</div>";
                }
                mysqli_stmt_close($up);
            }
        }
    } else {
        echo "<div class='error'>Please fill in all required fields for update.</div>";
    }
}

// If edit_id present in GET, load row for editing
if (isset($_GET['edit_id'])) {
    $eid = intval($_GET['edit_id']);
    if ($eid > 0) {
        $s = mysqli_prepare($conn, "SELECT t.id, t.course_id, t.instructor_id, t.day_of_week, t.start_time, t.end_time, t.location, t.semester, t.year FROM timetable t JOIN courses c ON t.course_id = c.id WHERE t.id = ? AND c.department = ? LIMIT 1");
        if ($s) {
            mysqli_stmt_bind_param($s, 'is', $eid, $department);
            mysqli_stmt_execute($s);
            $res = mysqli_stmt_get_result($s);
            $edit_row = mysqli_fetch_assoc($res);
            mysqli_stmt_close($s);
            if ($edit_row) $editing = true;
        }
    }
}

// Fetch courses for this department
$stmt = mysqli_prepare($conn, "SELECT id, course_code, course_name FROM courses WHERE department = ? ORDER BY course_code");
mysqli_stmt_bind_param($stmt, 's', $department);
mysqli_stmt_execute($stmt);
$courses_result = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

// Fetch instructors
$instructors_res = mysqli_query($conn, "SELECT id, fname, lname FROM instructors ORDER BY fname, lname");

// Fetch course->instructor assignments for this department (used to enforce "no timetable without assign")
$assign_map_stmt = mysqli_prepare($conn, "SELECT c.id AS course_id, i.id AS instructor_id, i.fname, i.lname
    FROM course_instructors ci
    JOIN courses c ON ci.course_id = c.id
    JOIN instructors i ON ci.instructor_id = i.id
    WHERE c.department = ?");
if ($assign_map_stmt) {
    mysqli_stmt_bind_param($assign_map_stmt, 's', $department);
    mysqli_stmt_execute($assign_map_stmt);
    $assign_map_res = mysqli_stmt_get_result($assign_map_stmt);
    $assigned_map = [];
    while ($am = mysqli_fetch_assoc($assign_map_res)) {
        $assigned_map[$am['course_id']] = [
            'id' => (int)$am['instructor_id'],
            'name' => trim($am['fname'] . ' ' . $am['lname'])
        ];
    }
    mysqli_stmt_close($assign_map_stmt);
} else {
    $assigned_map = [];
}

// Fetch current timetable entries for this department, ordered by day and time
$sql = "
    SELECT t.id, c.course_code, c.course_name, i.fname, i.lname, t.day_of_week, t.start_time, t.end_time, t.location, t.semester, t.year
    FROM timetable t
    JOIN courses c ON t.course_id = c.id
    JOIN instructors i ON t.instructor_id = i.id
    WHERE c.department = ?
    ORDER BY
        CASE t.day_of_week
            WHEN 'Monday' THEN 1
            WHEN 'Tuesday' THEN 2
            WHEN 'Wednesday' THEN 3
            WHEN 'Thursday' THEN 4
            WHEN 'Friday' THEN 5
            WHEN 'Saturday' THEN 6
            WHEN 'Sunday' THEN 7
            ELSE 8
        END,
        t.start_time
";

$stmt = mysqli_prepare($conn, $sql);
if (!$stmt) {
    die("Prepare failed: " . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt, 's', $department);
mysqli_stmt_execute($stmt);
$timetable_res = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);
?>

<h2>Department Timetable (<?php echo htmlspecialchars($department); ?>)</h2>

<h3>Add Timetable Entry</h3>
<form method="POST" style="max-width: 600px;">
    <label>Course</label><br>
    <select name="course_id" required>
        <option value="">-- Select Course --</option>
        <?php while ($course = mysqli_fetch_assoc($courses_result)): ?>
            <option value="<?php echo $course['id']; ?>" <?php echo ($editing && $edit_row && $edit_row['course_id'] == $course['id']) ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?>
            </option>
        <?php endwhile; ?>
    </select><br><br>

    <button type="button" id="assign_for_course">Assign instructor for selected course</button>
    <label>Instructor</label><br>
    <select name="instructor_id" required>
        <option value="">-- Select Instructor --</option>
        <?php while ($ins = mysqli_fetch_assoc($instructors_res)): ?>
            <option value="<?php echo $ins['id']; ?>" <?php echo ($editing && $edit_row && $edit_row['instructor_id'] == $ins['id']) ? 'selected' : ''; ?>>
                <?php echo htmlspecialchars($ins['fname'] . ' ' . $ins['lname']); ?>
            </option>
        <?php endwhile; ?>
    </select><br><br>

    <label>Day</label><br>
    <select name="day_of_week" required>
        <?php
        $days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
        foreach ($days as $d) {
            $sel = ($editing && $edit_row && $edit_row['day_of_week'] === $d) ? 'selected' : '';
            echo "<option value=\"$d\" $sel>$d</option>";
        }
        ?>
    </select><br><br>

    <label>Start Time</label><br>
    <input type="time" name="start_time" value="<?php echo $editing && $edit_row ? htmlspecialchars(substr($edit_row['start_time'],0,5)) : ''; ?>" required><br><br>

    <label>End Time</label><br>
    <input type="time" name="end_time" value="<?php echo $editing && $edit_row ? htmlspecialchars(substr($edit_row['end_time'],0,5)) : ''; ?>" required><br><br>

    <label>Room</label><br>
    <input type="text" name="location" placeholder="e.g. A101" maxlength="100" value="<?php echo $editing && $edit_row ? htmlspecialchars($edit_row['location']) : ''; ?>"><br><br>

    <label>Semester</label><br>
    <input type="text" name="semester" placeholder="e.g. Main" value="<?php echo $editing && $edit_row ? htmlspecialchars($edit_row['semester']) : 'Main'; ?>" required><br><br>

    <label>Year</label><br>
    <input type="text" name="year" value="<?php echo $editing && $edit_row ? htmlspecialchars($edit_row['year']) : date('Y'); ?>" required><br><br>

    <?php if ($editing): ?>
        <input type="hidden" name="update_id" value="<?php echo (int)$edit_row['id']; ?>">
        <button type="submit" name="update_timetable">Update Timetable Entry</button>
        <a href="timetable_hod.php" style="margin-left:10px">Cancel Edit</a>
    <?php else: ?>
        <button type="submit" name="add_timetable">Add Timetable Entry</button>
    <?php endif; ?>
</form>

<script>
document.getElementById('assign_for_course').addEventListener('click', function() {
    var sel = document.querySelector('select[name="course_id"]');
    if (!sel) return;
    var cid = sel.value;
    if (!cid) {
        alert('Please select a course first.');
        return;
    }
    // Open assign page with prefill
    window.location.href = 'assign_teacher.php?prefill_course_id=' + encodeURIComponent(cid);
});
</script>

<script>
// Mapping of course_id -> assigned instructor (id + name)
var assignedMap = <?php echo json_encode($assigned_map); ?> || {};

function updateInstructorSelect() {
    var courseSel = document.querySelector('select[name="course_id"]');
    var instrSel = document.querySelector('select[name="instructor_id"]');
    var addBtn = document.querySelector('button[name="add_timetable"]');
    if (!courseSel || !instrSel) return;
    var cid = courseSel.value;
    // clear current options
    instrSel.innerHTML = '';
    var defaultOpt = document.createElement('option');
    defaultOpt.value = '';
    defaultOpt.textContent = '-- Select Instructor --';
    instrSel.appendChild(defaultOpt);

    if (cid && assignedMap[cid]) {
        var a = assignedMap[cid];
        var opt = document.createElement('option');
        opt.value = a.id;
        opt.textContent = a.name + ' (assigned)';
        opt.selected = true;
        instrSel.appendChild(opt);
        instrSel.disabled = false;
        if (addBtn) addBtn.disabled = false;
    } else {
        var opt2 = document.createElement('option');
        opt2.value = '';
        opt2.textContent = '-- No instructor assigned. Assign first --';
        instrSel.appendChild(opt2);
        instrSel.disabled = false;
        if (addBtn) addBtn.disabled = true;
    }
}

document.querySelector('select[name="course_id"]').addEventListener('change', updateInstructorSelect);
// initialize on load
updateInstructorSelect();
</script>

<h3>Current Timetable</h3>

<table border="1" cellpadding="5" cellspacing="0" style="width:100%; border-collapse: collapse;">
    <thead>
        <tr style="background-color:#003366; color:white;">
            <th>Course</th>
            <th>Instructor</th>
            <th>Day</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Room</th>
            <th>Semester</th>
            <th>Year</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php if (mysqli_num_rows($timetable_res) === 0): ?>
            <tr><td colspan="8" style="text-align:center;">No timetable entries found.</td></tr>
        <?php else: ?>
            <?php while ($row = mysqli_fetch_assoc($timetable_res)): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['course_code'] . ' - ' . $row['course_name']); ?></td>
                <td><?php echo htmlspecialchars($row['fname'] . ' ' . $row['lname']); ?></td>
                <td><?php echo htmlspecialchars($row['day_of_week']); ?></td>
                <td><?php echo htmlspecialchars(substr($row['start_time'], 0, 5)); ?></td>
                <td><?php echo htmlspecialchars(substr($row['end_time'], 0, 5)); ?></td>
                <td><?php echo htmlspecialchars($row['location']); ?></td>
                <td><?php echo htmlspecialchars($row['semester']); ?></td>
                <td><?php echo htmlspecialchars($row['year']); ?></td>
                <td>
                    <a href="timetable_hod.php?edit_id=<?php echo (int)$row['id']; ?>">Edit</a>
                    <form method="POST" style="display:inline" onsubmit="return confirm('Delete this timetable entry?');">
                        <input type="hidden" name="delete_id" value="<?php echo (int)$row['id']; ?>">
                        <button type="submit" name="delete_timetable" style="background:red;color:white;border:none;padding:4px;margin-left:6px">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php endif; ?>
    </tbody>
</table>

<?php
include __DIR__ . '/../includes/footer.php';
?>

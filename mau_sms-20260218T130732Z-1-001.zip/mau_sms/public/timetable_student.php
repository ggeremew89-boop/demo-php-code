<?php
require_once __DIR__ . '/../includes/auth.php';

// Allow student, department_head, instructor
require_role(['student', 'department_head', 'instructor']);

include __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'] ?? '';

if (!$user_id) {
    die("User not logged in.");
}

if ($role === 'student') {
    // Fetch student timetable
    $student_res = mysqli_query($conn, "SELECT id FROM students WHERE user_id = $user_id LIMIT 1");
    if (!$student_res || mysqli_num_rows($student_res) === 0) {
        die("Student record not found.");
    }
    $student = mysqli_fetch_assoc($student_res);
    $student_id = intval($student['id']);
    
    $sql = "
        SELECT 
            t.day_of_week, t.start_time, c.course_code, c.course_name,
            i.fname AS instructor_fname, i.lname AS instructor_lname, t.location
        FROM registrations r
        JOIN timetable t ON r.course_id = t.course_id
        JOIN courses c ON t.course_id = c.id
        JOIN instructors i ON t.instructor_id = i.id
        WHERE r.student_id = $student_id
        ORDER BY FIELD(t.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
        t.start_time
    ";
} elseif ($role === 'department_head') {
    // Fetch department head department
    $dept_res = mysqli_query($conn, "SELECT department FROM department_heads WHERE user_id = $user_id LIMIT 1");
    if (!$dept_res || mysqli_num_rows($dept_res) == 0) {
        die("Department Head record not found.");
    }
    $dept_head = mysqli_fetch_assoc($dept_res);
    $department = mysqli_real_escape_string($conn, $dept_head['department']);
    
    // Fetch timetable for courses in department
    $sql = "
        SELECT t.day_of_week, t.start_time, c.course_code, c.course_name,
               i.fname AS instructor_fname, i.lname AS instructor_lname, t.location
        FROM timetable t
        JOIN courses c ON t.course_id = c.id
        JOIN instructors i ON t.instructor_id = i.id
        WHERE c.department = '$department'
        ORDER BY FIELD(t.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
        t.start_time
    ";
} elseif ($role === 'instructor') {
    // Fetch instructor record
    $inst_res = mysqli_query($conn, "SELECT id FROM instructors WHERE user_id = $user_id LIMIT 1");
    if (!$inst_res || mysqli_num_rows($inst_res) === 0) {
        die("Instructor record not found.");
    }
    $instructor = mysqli_fetch_assoc($inst_res);
    $instructor_id = intval($instructor['id']);
    
    // Fetch timetable for this instructor
    $sql = "
        SELECT t.day_of_week, t.start_time, c.course_code, c.course_name,
               i.fname AS instructor_fname, i.lname AS instructor_lname, t.location
        FROM timetable t
        JOIN courses c ON t.course_id = c.id
        JOIN instructors i ON t.instructor_id = i.id
        WHERE t.instructor_id = $instructor_id
        ORDER BY FIELD(t.day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'),
        t.start_time
    ";
} else {
    die("Access denied: Invalid role.");
}

$res = mysqli_query($conn, $sql);
if (!$res) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<h2>Timetable</h2>

<table border="1" cellpadding="5" cellspacing="0" style="width:100%; border-collapse: collapse;">
    <thead>
        <tr style="background-color:#003366; color:white;">
            <th>Day</th>
            <th>Time</th>
            <th>Course</th>
            <th>Instructor</th>
            <th>Location</th>
        </tr>
    </thead>
    <tbody>
        <?php if (mysqli_num_rows($res) === 0): ?>
            <tr><td colspan="5" style="text-align:center;">No timetable entries found.</td></tr>
        <?php else: ?>
            <?php while ($row = mysqli_fetch_assoc($res)): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['day_of_week']); ?></td>
                <td><?php echo htmlspecialchars(substr($row['start_time'], 0, 5)); ?></td>
                <td><?php echo htmlspecialchars($row['course_code'] . ' - ' . $row['course_name']); ?></td>
                <td><?php echo htmlspecialchars($row['instructor_fname'] . ' ' . $row['instructor_lname']); ?></td>
                <td><?php echo htmlspecialchars($row['location']); ?></td>
            </tr>
            <?php endwhile; ?>
        <?php endif; ?>
    </tbody>
</table>

<?php include __DIR__ . '/../includes/footer.php'; ?>

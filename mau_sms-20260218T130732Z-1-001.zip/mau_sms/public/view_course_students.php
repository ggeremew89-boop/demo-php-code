<?php
session_start();
require_once __DIR__ . '/../includes/auth.php';
// allow instructors, department heads, admins and registrars to view
require_role(['instructor','department_head','admin','superadmin','registrar']);
require_once __DIR__ . '/../includes/db.php';
include __DIR__ . '/../includes/header.php';

$course_id = intval($_GET['course_id'] ?? 0);
if ($course_id <= 0) {
    die("Invalid course id.");
}

// If department_head, ensure the course belongs to their department
$user_id = $_SESSION['user_id'] ?? 0;
$is_dh = has_role('department_head') || (isset($_SESSION['roles']) && in_array('department_head', $_SESSION['roles']));
if ($is_dh) {
    $stmt = mysqli_prepare($conn, "SELECT c.department FROM courses c JOIN department_heads dh ON dh.department = c.department WHERE c.id = ? AND dh.user_id = ? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'ii', $course_id, $user_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if (mysqli_num_rows($res) === 0) {
        die("You do not have permission to view students for this course.");
    }
    mysqli_stmt_close($stmt);
}

// Fetch course info
$cstmt = mysqli_prepare($conn, "SELECT id, course_code, course_name FROM courses WHERE id = ? LIMIT 1");
mysqli_stmt_bind_param($cstmt, 'i', $course_id);
mysqli_stmt_execute($cstmt);
$cres = mysqli_stmt_get_result($cstmt);
$course = mysqli_fetch_assoc($cres);
mysqli_stmt_close($cstmt);
if (!$course) die("Course not found.");

// Fetch registered students for the course
$stmt = mysqli_prepare($conn, "SELECT s.id, s.student_number, s.fname, s.lname, sr.status FROM registrations r JOIN students s ON r.student_id = s.id LEFT JOIN student_registration sr ON sr.student_id = s.id AND sr.semester = r.semester WHERE r.course_id = ? ORDER BY s.fname");
mysqli_stmt_bind_param($stmt, 'i', $course_id);
mysqli_stmt_execute($stmt);
$students = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

?>

<h2>Students Registered for <?= htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']) ?></h2>

<?php if (!$students || mysqli_num_rows($students) === 0): ?>
    <p>No students registered for this course.</p>
<?php else: ?>
    <table border="1" cellpadding="6" cellspacing="0" width="100%">
        <tr style="background:#003366;color:#fff">
            <th>ID</th>
            <th>Student Number</th>
            <th>Name</th>
            <th>Registration Status</th>
            <th>Action</th>
        </tr>
        <?php while ($s = mysqli_fetch_assoc($students)): ?>
            <tr>
                <td><?= (int)$s['id'] ?></td>
                <td><?= htmlspecialchars($s['student_number']) ?></td>
                <td><?= htmlspecialchars($s['fname'] . ' ' . $s['lname']) ?></td>
                <td><?= htmlspecialchars($s['status'] ?? 'Not Registered') ?></td>
                <td>
                    <a href="student_edit.php?id=<?= (int)$s['id'] ?>">Edit</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php
session_start();

require_once __DIR__ . '/../includes/auth.php';
require_role(['department_head','superadmin','admin','registrar']);

require_once __DIR__ . '/../includes/db.php';

$user_id   = $_SESSION['user_id'] ?? null;
$user_role = $_SESSION['role'] ?? null;

if (!$user_id || !$user_role) {
    die("User not logged in properly.");
}

/* ===============================
   GET DEPARTMENT FOR HOD
================================ */
$department = null;

if ($user_role === 'department_head') {
    $stmt = mysqli_prepare(
        $conn,
        "SELECT department FROM department_heads WHERE user_id=?"
    );
    mysqli_stmt_bind_param($stmt, 'i', $user_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if (!$row) {
        die("Department Head record not found.");
    }
    $department = $row['department'];
}

/* ===============================
   CURRENT SEMESTER (change as needed)
================================ */
$current_semester = "2025-1";

/* ===============================
   HANDLE REGISTRATION STATUS UPDATE
   (Only registrars may update)
================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_reg_status'])) {
    if ($user_role !== 'registrar') {
        die('Permission denied.');
    }

    $student_id = intval($_POST['student_id'] ?? 0);
    $status = trim($_POST['status'] ?? '');
    if ($student_id <= 0 || $status === '') {
        header('Location: view_registrations.php');
        exit;
    }

    $stmt = mysqli_prepare($conn, "SELECT id FROM student_registration WHERE student_id=? AND semester=? LIMIT 1");
    mysqli_stmt_bind_param($stmt, 'is', $student_id, $current_semester);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $existing = mysqli_fetch_assoc($res);
    mysqli_stmt_close($stmt);

    if ($existing) {
        $stmt = mysqli_prepare($conn, "UPDATE student_registration SET status=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, 'si', $status, $existing['id']);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO student_registration (student_id, semester, status) VALUES (?,?,?)");
        mysqli_stmt_bind_param($stmt, 'iss', $student_id, $current_semester, $status);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    $stmt = mysqli_prepare($conn, "UPDATE students SET registration_status=? WHERE id=?");
    mysqli_stmt_bind_param($stmt, 'si', $status, $student_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: view_registrations.php');
    exit;
}

/* ===============================
   FETCH STUDENTS WITH REGISTRATION STATUS
================================ */
if ($department) {
        $stmt = mysqli_prepare(
                $conn,
                "SELECT students.*,
                                COALESCE(sr.status, students.registration_status, IF(r.reg_count>0, 'Registered', NULL)) AS reg_status
                 FROM students
                 LEFT JOIN student_registration sr
                     ON sr.student_id = students.id AND sr.semester = ?
                 LEFT JOIN (
                     SELECT student_id, COUNT(*) AS reg_count
                     FROM registrations
                     WHERE semester = ?
                     GROUP BY student_id
                 ) r ON r.student_id = students.id
                 WHERE students.department = ?
                 ORDER BY students.fname"
        );
        mysqli_stmt_bind_param($stmt, 'sss', $current_semester, $current_semester, $department);
        mysqli_stmt_execute($stmt);
        $students = mysqli_stmt_get_result($stmt);
} else {
        $stmt = mysqli_prepare(
                $conn,
                "SELECT students.*,
                                COALESCE(sr.status, students.registration_status, IF(r.reg_count>0, 'Registered', NULL)) AS reg_status
                 FROM students
                 LEFT JOIN student_registration sr
                     ON sr.student_id = students.id AND sr.semester = ?
                 LEFT JOIN (
                     SELECT student_id, COUNT(*) AS reg_count
                     FROM registrations
                     WHERE semester = ?
                     GROUP BY student_id
                 ) r ON r.student_id = students.id
                 ORDER BY students.fname"
        );
        mysqli_stmt_bind_param($stmt, 'ss', $current_semester, $current_semester);
        mysqli_stmt_execute($stmt);
        $students = mysqli_stmt_get_result($stmt);
}

if (!$students) {
    die("Student Query Error: " . mysqli_error($conn));
}

/* ===============================
   FETCH INSTRUCTORS
================================ */
if ($department) {
    $stmt = mysqli_prepare(
        $conn,
        "SELECT * FROM instructors WHERE department = ? ORDER BY fname"
    );
    mysqli_stmt_bind_param($stmt, 's', $department);
    mysqli_stmt_execute($stmt);
    $instructors = mysqli_stmt_get_result($stmt);
} else {
    $instructors = mysqli_query(
        $conn,
        "SELECT * FROM instructors ORDER BY fname"
    );
}

if (!$instructors) {
    die("Instructor Query Error: " . mysqli_error($conn));
}

include __DIR__ . '/../includes/header.php';
?>

<h2>
    Students & Instructors
    <?php if ($department): ?>
        - Department: <?= htmlspecialchars($department) ?>
    <?php else: ?>
        (All Departments)
    <?php endif; ?>
</h2>

<hr>

<!-- ===============================
        STUDENTS TABLE
================================ -->
<h3>Students</h3>

<table border="1" width="100%" cellpadding="5" cellspacing="0">
<thead style="background:#003366;color:white;">
<tr>
    <th>ID</th>
    <th>Student Number</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Gender</th>
    <th>Department</th>
    <th>Email</th>
    <th>Registration Status</th>
    <th>Action</th>
</tr>
</thead>
<tbody>

<?php if (mysqli_num_rows($students) == 0): ?>
<tr>
    <td colspan="9" align="center">No students found</td>
</tr>
<?php else: while ($s = mysqli_fetch_assoc($students)): ?>
<tr>
    <td><?= $s['id'] ?></td>
    <td><?= htmlspecialchars($s['student_number']) ?></td>
    <td><?= htmlspecialchars($s['fname']) ?></td>
    <td><?= htmlspecialchars($s['lname']) ?></td>
    <td><?= htmlspecialchars($s['gender']) ?></td>
    <td><?= htmlspecialchars($s['department']) ?></td>
    <td><?= htmlspecialchars($s['email'] ?? '-') ?></td>
    <td>
        <?php if ($user_role === 'registrar'): ?>
            <form method="post" style="margin:0">
                <input type="hidden" name="student_id" value="<?= $s['id'] ?>">
                <select name="status">
                    <?php
                    $options = ['Not Registered','Pending','Registered','Cancelled'];
                    $current = $s['reg_status'] ?? 'Not Registered';
                    foreach ($options as $opt):
                    ?>
                        <option value="<?= htmlspecialchars($opt) ?>" <?= $current === $opt ? 'selected' : '' ?>><?= htmlspecialchars($opt) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" name="update_reg_status">Save</button>
            </form>
        <?php else: ?>
            <?= htmlspecialchars($s['reg_status'] ?? 'Not Registered') ?>
        <?php endif; ?>
    </td>
    <td>
        <?php if ($user_role === 'superadmin' || $user_role === 'admin' || $user_role === 'registrar' || ($user_role === 'department_head' && $s['department'] === $department)): ?>
            <a href="student_edit.php?id=<?= $s['id'] ?>">✏ Edit</a> |
            <a href="student_delete.php?id=<?= $s['id'] ?>"
               onclick="return confirm('Delete this student?')">🗑 Delete</a>
        <?php else: ?>
            —
        <?php endif; ?>
    </td>
</tr>
<?php endwhile; endif; ?>

</tbody>
</table>

<br><hr><br>

<!-- ===============================
        INSTRUCTORS TABLE
================================ -->
<h3>Instructors</h3>

<table border="1" width="100%" cellpadding="5" cellspacing="0">
<thead style="background:#003366;color:white;">
<tr>
    <th>ID</th>
    <th>Instructor Code</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Department</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Action</th>
</tr>
</thead>
<tbody>

<?php if (mysqli_num_rows($instructors) == 0): ?>
<tr>
    <td colspan="8" align="center">No instructors found</td>
</tr>
<?php else: while ($i = mysqli_fetch_assoc($instructors)): ?>
<tr>
    <td><?= $i['id'] ?></td>
    <td><?= htmlspecialchars($i['instructor_code']) ?></td>
    <td><?= htmlspecialchars($i['fname']) ?></td>
    <td><?= htmlspecialchars($i['lname']) ?></td>
    <td><?= htmlspecialchars($i['department']) ?></td>
    <td><?= htmlspecialchars($i['email'] ?? '-') ?></td>
    <td><?= htmlspecialchars($i['phone'] ?? '-') ?></td>
    <td>
        <?php if ($user_role === 'superadmin' || $user_role === 'admin' || ($user_role === 'department_head' && $i['department'] === $department)): ?>
            <a href="instructor_edit.php?id=<?= $i['id'] ?>">✏ Edit</a> |
            <a href="instructor_delete.php?id=<?= $i['id'] ?>"
               onclick="return confirm('Delete this instructor?')">🗑 Delete</a>
        <?php else: ?>
            —
        <?php endif; ?>
    </td>
</tr>
<?php endwhile; endif; ?>

</tbody>
</table>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

// Check if user is logged in
$user_id = $_SESSION['user_id'] ?? 0;
if (!$user_id) {
    die("You must be logged in to view results.");
}

$error = '';
$results = [];
$course_code = $_GET['course_code'] ?? '';

// Get student ID for the logged-in user
$stmt = mysqli_prepare($conn, "SELECT id FROM students WHERE user_id = ? LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $student_id);
if (!mysqli_stmt_fetch($stmt)) {
    die("Student record not found for logged in user.");
}
mysqli_stmt_close($stmt);

// Build the query to get results only for this student
$sql = "
    SELECT 
        sr.id,
        s.student_number,
        s.fname,
        s.lname,
        c.course_code,
        c.course_name,
        sr.semester,
        sr.year,
        sr.continuous_mark,
        sr.final_mark,
        sr.status
    FROM student_results sr
    JOIN students s ON sr.student_id = s.id
    JOIN courses c ON sr.course_id = c.id
    WHERE sr.student_id = ?
";

if ($course_code) {
    $sql .= " AND c.course_code = ?";
}

$sql .= " ORDER BY sr.year DESC, sr.semester DESC, c.course_code";

// Prepare and execute statement
$stmt = mysqli_prepare($conn, $sql);

if ($course_code) {
    mysqli_stmt_bind_param($stmt, "is", $student_id, $course_code);
} else {
    mysqli_stmt_bind_param($stmt, "i", $student_id);
}

mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

if ($res) {
    $results = mysqli_fetch_all($res, MYSQLI_ASSOC);
} else {
    $error = "Error fetching results: " . mysqli_error($conn);
}

mysqli_stmt_close($stmt);

// Include your header
include __DIR__ . '/../includes/header.php';
?>

<h2>Your Results<?php if ($course_code) echo " for Course: " . htmlspecialchars($course_code); ?></h2>

<?php if ($error): ?>
    <div style="color:red;"><?php echo htmlspecialchars($error); ?></div>
<?php elseif (empty($results)): ?>
    <p>No results found<?php if ($course_code) echo " for this course"; ?>.</p>
<?php else: ?>
    <table border="1" cellpadding="5" cellspacing="0" style="width:100%; border-collapse: collapse;">
        <thead style="background:#003366; color:white;">
            <tr>
               
                <th>Student Number</th>
                <th>Student Name</th>
                <th>Course Code</th>
                <th>Course Name</th>
                <th>Semester</th>
                <th>Year</th>
                <th>Continuous Mark</th>
                <th>Final Mark</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($results as $row): ?>
                <tr>
                 
                    <td><?= htmlspecialchars($row['student_number']) ?></td>
                    <td><?= htmlspecialchars($row['fname'] . ' ' . $row['lname']) ?></td>
                    <td><?= htmlspecialchars($row['course_code']) ?></td>
                    <td><?= htmlspecialchars($row['course_name']) ?></td>
                    <td><?= htmlspecialchars($row['semester']) ?></td>
                    <td><?= htmlspecialchars($row['year']) ?></td>
                    <td><?= htmlspecialchars($row['continuous_mark']) ?></td>
                    <td><?= htmlspecialchars($row['final_mark']) ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
